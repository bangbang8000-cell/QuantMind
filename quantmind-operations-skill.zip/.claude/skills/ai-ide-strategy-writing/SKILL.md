---
name: ai-ide-strategy-writing
description: "AI-IDE 写策略 — 用 AI 生成 Qlib 量化策略代码、自然语言条件选股、策略落库。在 QuantBot / Claude Code 中让 AI 写策略、生成 Qlib 策略、从自然语言创建策略、云端保存策略时使用。触发词：AI写策略、写策略、生成策略、策略代码、AI-IDE、自然语言生成策略、帮我写个策略、云端策略"
---

# AI-IDE 写策略技能

用 AI 生成 Qlib 量化策略：自然语言条件选股 → 生成策略代码 → 云端落库。配合回测中心验证效果。

## 认证

```bash
BASE=http://127.0.0.1:8000
TOKEN=$(curl -s -X POST $BASE/api/v1/auth/login -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"admin123","tenant_id":"default"}' \
  | python3 -c "import sys,json; print(json.load(sys.stdin).get('access_token',''))")
AUTH="Authorization: Bearer $TOKEN"
CT="Content-Type: application/json"
```

## 1. 自然语言选股条件解析

### 1.1 解析文本为条件
```bash
curl -s -X POST -H "$AUTH" -H "$CT" "$BASE/api/v1/strategy/parse-text" \
  -d '{"text":"市值大于500亿且ROE大于15%的沪深300成分股，剔除ST"}'
# 返回: {dsl, mapping, quantdb_filters, suggestions}
```

### 1.2 结构化条件解析
```bash
curl -s -X POST -H "$AUTH" -H "$CT" "$BASE/api/v1/strategy/parse-conditions" \
  -d '{"conditions":{"type":"numeric","factor":"pe","operator":"<","threshold":15}}'
# 返回: {dsl: "SELECT symbol WHERE pe < 15", quantdb_filters}
```

## 2. 生成 Qlib 策略（AI-IDE 核心）

### 2.1 异步生成（推荐，避免超时）
```bash
# 提交生成任务
curl -s -X POST -H "$AUTH" -H "$CT" "$BASE/api/v1/strategy/generate-qlib/async" \
  -d '{
    "user_id": "00000001",
    "conditions": {"type":"composite","op":"and","children":[
      {"type":"numeric","factor":"pe","operator":"<","threshold":15},
      {"type":"numeric","factor":"roe","operator":">","threshold":10}
    ]},
    "market": "CN",
    "pool_content": "600519.SH\n000858.SZ\n601318.SH\n",
    "qlib_params": {
      "strategy_type": "TopkDropoutStrategy",
      "topk": 20,
      "n_drop": 5,
      "rebalance_period": "week"
    }
  }'
# 返回: {task_id, status}

# 轮询任务状态（pending→running→completed/failed）
curl -s -H "$AUTH" "$BASE/api/v1/strategy/generate-qlib/tasks/{task_id}"
# 返回: {status, result: {success, code(策略代码), error}}
```

### 2.2 同步生成（小策略可用）
```bash
curl -s -X POST -H "$AUTH" -H "$CT" "$BASE/api/v1/strategy/generate-qlib" \
  -d '{"user_id":"00000001","conditions":{},"qlib_params":{"strategy_type":"TopkDropoutStrategy","topk":20}}'
```

**GenerateQlibRequest 参数**：
| 字段 | 说明 |
|---|---|
| `user_id` | 用户 ID |
| `conditions` | 选股条件（可空） |
| `pool_content` | 股票池代码（每行一个） |
| `pool_file_key` | 兼容旧字段（COS key） |
| `market` | CN / HK / US / CRYPTO |
| `qlib_params` | `{strategy_type, topk, n_drop, rebalance_period}` |

**返回的 `code`** 是可直接运行的 Qlib 策略代码。

## 3. 生成后的策略代码处理

生成得到 `code` 后，策略需要按 Qlib 规范定义：
- **类名**：通常 `Strategy`（需继承 `qlib.contrib.strategy.SignalBasedStrategy` 或 `TopkDropoutStrategy`）
- **`generate_trade_decision`**：核心方法，返回买卖决策
- **`reset`**：必须兼容可变参数 `def reset(self, *args, **kwargs)`

## 4. 策略云端落库

### 4.1 保存策略
```bash
curl -s -X POST -H "$AUTH" -H "$CT" "$BASE/api/v1/strategies" \
  -d '{
    "name": "AI生成-低估值策略",
    "description": "PE<15 且 ROE>10",
    "strategy_type": "TopkDropoutStrategy",
    "params": {"topk": 20, "n_drop": 5},
    "code": "class Strategy: ...",  # 生成的 Qlib 代码
    "market": "CN"
  }'
```

### 4.2 策略列表 / 模板
```bash
curl -s -H "$AUTH" "$BASE/api/v1/strategies"
curl -s -H "$AUTH" "$BASE/api/v1/strategies/templates"
```

### 4.3 激活策略
```bash
curl -s -X POST -H "$AUTH" "$BASE/api/v1/strategies/{strategy_id}/activate"
```

## 5. 实战流程（推荐）

当用户要求"写个策略"时：
1. **理解需求**：确认选股条件（市值/PE/ROE/动量/行业等）
2. **解析条件**：`parse-text` 或 `parse-conditions` 验证字段可识别
3. **生成代码**：`generate-qlib/async` 提交任务，轮询拿策略代码
4. **保存落库**：`/strategies` POST 保存到云端
5. **回测验证**：用 [[backtest-center]] 技能跑回测
6. **调优迭代**：根据回测结果调参数，重新生成

## 6. 常见问题

| 现象 | 处理 |
|---|---|
| 任务一直 pending | 检查 LLM API Key（AI_IDE_LLM_API_KEY），等待生成 |
| 生成失败 | 看 `result.error`，通常条件字段不被识别 |
| 策略代码报错 | 检查类名/方法名是否符合 Qlib 规范 |
| 想用股票池 | 用 `pool_content` 直接传代码，或用 [[smart-strategy-stock-picking]] 生成 |
