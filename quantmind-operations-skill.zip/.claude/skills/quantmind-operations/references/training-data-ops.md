# 模型训练与数据操作参考

## 数据同步链

```
外部数据源 (TDX/akshare/baostock/QuantDB)
      ↓
quantdb_daily_sync.py — QuantDB parquet 同步
      ↓
quantdb_hub (DuckDB 视图) — 全字段访问
      ↓
stock_daily_latest (PG 1068万行) — 快照表
      ↓
qlib_data_builder — Qlib 二进制缓存
      ↓
update_feature_parquet.py — 151 维特征快照 (db/feature_snapshots/)
```

## 数据平台结构

- **QuantDB 数据目录**：`data/quantdb/`（6 大类：kline/base_sector/financial/technical_derived/ml_datasets）
- **字段路由**：`config/data_sources/field_routing.yaml`（quantdb_local 为主源）
- **特征快照**：`db/feature_snapshots/model_features_*.parquet`（13 文件，~15GB，2136万行）
- **覆盖日期**：2016-01-04 ~ 2026-08-07

## 训练管线

```
run-training → submit_training_job → LocalDockerOrchestrator
  → 校验 features 在 parquet 存在性
  → 启动训练容器 (Docker)
  → 产出模型到 /models
  → deploy_to_production 决定是否入生产
```

### 关键 payload 字段

| 字段 | 默认 | 说明 |
|---|---|---|
| `model_type` | lightgbm | lightgbm/xgboost/catboost/linear/dl |
| `model_types` | — | 多模型列表（ensemble 用） |
| `ensemble` | none | none/stacking/blending/voting |
| `job_name` | unnamed | 任务名 |
| `train_start/end` | 2022-01-01 / 2024-12-31 | 训练区间 |
| `features` | [] | 特征 key 列表（从 feature-catalog 取） |
| `feature_categories` | [] | 按类别选特征（如 momentum） |
| `num_boost_round` | 1000 | 迭代轮数 |
| `target_horizon_days` | 1 | 预测 horizon |
| `target_mode` | return | 标签类型 |
| `deploy_to_production` | false | 是否入生产 |

### 训练状态机
`pending → running → completed` 或 `pending → running → failed`

## 模型注册表

- **用户模型**：`/api/v1/models`（用户态 CRUD）
- **生产模型**：`models/production/model_qlib/`
- **默认模型**：用户默认生效模型（推理用）
- **融合模型**：`/api/v1/models/ensemble/create` 百分位加权合成

## 推理链路

```
precheck-inference → inference/run → inference/batch (批量)
  → 信号表 trade_date = T+1
  → inference/runs (历史) / inference/stock/{symbol}/history
```

## 运维注意事项

1. **数据新鲜度**：`/freshness` 查看各表最新日期；交易日收盘后需同步
2. **特征快照**：`update-feature-parquet?year=YYYY` 异步生成
3. **同步并发**：daily-sync 是 Celery 异步任务，提交后轮询 status
4. **服务健康**：`/health` 检查 api/engine/trade/stream 四服务
5. **K线缓存**：`market_kline.py` 内存缓存 TTL 5 分钟，冷读 2-3s
