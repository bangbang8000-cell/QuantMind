# QuantMind Skills（Claude Code 技能包）

QuantMind 提供一组完整的 **Claude Code / QuantBot 技能**（Skills），让 AI 助手能够直接调用平台的量化功能：数据分析、因子挖掘、模型训练、策略生成、回测、模拟交易等。

每个技能是 `.claude/skills/<skill-name>/SKILL.md`，通过自然语言触发词激活。安装后，QuantBot / Claude Code 可自动识别用户意图并调用对应技能完成操作。

## 安装方式

### 方式一：从技能包安装（推荐）

打包文件：`quantmind-operations-skill.zip`，包含全部技能。

```bash
# 解压到 Claude Code 全局技能目录
unzip quantmind-operations-skill.zip -d ~/.claude/
```

### 方式二：从项目仓库安装

项目根目录 `.claude/skills/` 下即为全部技能，直接使用或复制到 `~/.claude/skills/`。

## 技能总览

| 技能 | 触发词 | 功能 |
|------|--------|------|
| [quantmind-operations](#quantmind-operations) | 模型训练、模型管理、数据更新、RSS、新闻分析 | 平台运营操作总指南：模型训练 5 步流程、模型管理、后台数据更新、字段信息查询、RSS 新闻对接 |
| [stock-market-analysis](#stock-market-analysis) | 分析市场、数据分析、全市场扫描、行业轮动、导出CSV | 股票市场深度数据分析与导出（多市场） |
| [smart-strategy-stock-picking](#smart-strategy-stock-picking) | 选股、筛选股票、股票池、条件选股 | 基于 QuantDB 数据的条件选股（自然语言 / 条件） |
| [ai-ide-strategy-writing](#ai-ide-strategy-writing) | 写策略、生成策略、策略代码、AI-IDE | AI 生成 Qlib 量化策略代码，自然语言条件选股 |
| [backtest-center](#backtest-center) | 回测、回测中心、策略对比、参数优化 | Qlib 回测：快速回测、专家模式、策略对比、参数优化 |
| [batch-inference-analysis](#batch-inference-analysis) | 分析批量推理、解读信号、每日选股 | 批量推理结果分析：每日信号、行业轮动、个股分数 |
| [rd-agent-factor-mining](#rd-agent-factor-mining) | 挖因子、因子挖掘、因子演化、RD-Agent | 自动调用 RD-Agent 进行因子挖掘（多市场） |
| [quantdb-sdk](#quantdb-sdk) | quantdb、数据key、数据集、查询K线 | QuantDB 数据 SDK：API Key、数据集目录、字段查询 |
| [simulation-trading](#simulation-trading) | 模拟交易、模拟下单、查持仓、查账户 | 模拟交易：下单买卖、持仓管理、成交查询 |

---

## 国际市场支持

QuantMind 全面支持 **A 股 / 港股 / 美股 / 区块链 / 期货** 五大市场。技能在对应市场自动切换数据源与训练配置。

### 国际市场数据接入

| 市场 | 本地数据中枢 | 数据源 | 同步脚本 | 特征文件 |
|------|-------------|--------|----------|----------|
| **A 股** | `data/quantdb/`（QuantDBDataHub） | QuantDB、baostock、akshare 等 17 适配器 | `quantdb_daily_sync.py` | `model_features_core.parquet` |
| **港股** | `data/quanthk/`（QuantHKDataHub） | Yahoo Finance、akshare（CCASS/南向）、付费数据 | `quanthk_daily_sync.py`、`quanthk_akshare_kline.py` | `model_features_hk.parquet` |
| **美股** | `data/quantus/`（QuantUSDataHub） | Yahoo Finance、simonlin | `quantus_daily_sync.py` | `model_features_us.parquet` |
| **区块链** | `data/quantbc/`（QuantBCDataHub） | Binance（5min 聚合） | `quantbc_daily_sync.py` | `model_features_crypto.parquet` |
| **期货** | `data/quantfutures/`（QuantFuturesDataHub） | akshare（贵金属/商品/国际） | `quantfutures_daily_sync.py` | `model_features_futures.parquet` |

- 所有市场统一 Parquet 格式（`symbol/time/open/high/low/close/volume/amount`），经 `qlib_data_builder.py` 生成 Qlib 二进制缓存（`.qlib_cache/{market}_data`）
- 统一通过 `backend/shared/qlib_paths.py` 的 `resolve_qlib_provider_uri(market)` 按市场解析数据路径

### 国际市场模型训练

模型训练已实现 **按市场切换**：

- **特征目录市场过滤** — `config/features/model_training_feature_catalog_v1.json` 每个特征带 `markets` 标签；训练时按所选市场过滤可用特征（A股 197 全量，港股/美股/区块链各 100+，期货 118）
- **训练数据源切换** — `docker/training/train.py` 的 `load_data(market=...)` 按市场读取对应特征 parquet（`model_features_{market}.parquet`）
- **模型市场分段存储** — `backend/shared/model_registry.py`：模型 ID 带市场前缀（`mdl_{market}_...`），非 A 股模型存储到 `{user}/{market}/` 子目录；`list_models(market=...)` 支持按市场过滤
- **推理脚本市场参数** — 推理模板（`inference_ensemble*.py`）支持 `--market`，按模型 metadata 的市场自动发现模型、加载对应数据
- **回测中心** — `backtestConfig` 按市场切换 Qlib provider_uri / 基准指数 / 股票池

#### 国际市场训练示例

```bash
# 港股模型训练（后端 API）
curl -X POST $BASE/api/v1/models/run-training \
  -H "$AUTH" -H "$CT" \
  -d '{
    "model_type": "lightgbm",
    "display_name": "HK_volume_model",
    "train_start": "2022-01-01",
    "train_end": "2025-12-31",
    "features": ["mom_ret_20d", "vol_atr_20", "liq_amihud_20"],
    "context": {
      "market": "HK",
      "benchmark": "HSI",
      "initial_capital": 1000000
    }
  }'
```

---

## 技能详情

### quantmind-operations

**平台运营操作总指南**。覆盖模型训练（5 步流程：特征选择 → 训练目标 → 参数配置 → 执行训练 → 结果入库）、模型管理、后台数据更新、字段信息查询、RSS 新闻对接与分析。

**参考文件**：
- `references/news-analysis.md` — RSS 新闻对接与分析
- `references/training-data-ops.md` — 训练数据运营

### stock-market-analysis

**股票市场深度数据分析与导出**。全市场信号扫描、行业轮动、个股全维度分析、数据挖掘、CSV/Excel 导出。支持多市场（A股/港股/美股）。

### smart-strategy-stock-picking

**智能策略选股**。基于 QuantDB 数据的条件选股，支持自然语言或结构化条件筛选股票、构建股票池、生成策略。选股池按市场动态加载（港股/美股/区块链/期货从本地 parquet 读取标的 + 名称/PE/市值补充）。

### ai-ide-strategy-writing

**AI-IDE 写策略**。用 AI 生成 Qlib 量化策略代码、自然语言条件选股、策略落库。

### backtest-center

**回测中心**。快速回测、专家模式、回测历史、策略对比、参数优化、策略管理、高级分析。回测配置按市场切换（Qlib provider_uri、基准指数、股票池）。

### batch-inference-analysis

**批量推理结果分析**。用选股策略方法论分析每日信号、行业轮动、个股分数区间、负分参考。基于推理回测数据（信号表 trade_date=T+1）。

### rd-agent-factor-mining

**RD-Agent 因子挖掘**。自动调用 RD-Agent 进行因子演化，支持 **A股/港股/美股/区块链/期货** 五市场，各市场使用专属因子集（Alpha158 / HK_ALPHA / US_ALPHA / CRYPTO_ALPHA / FUTURES_ALPHA）与 Qlib 缓存。

### quantdb-sdk

**QuantDB 数据 SDK**。API Key 配置、数据集目录、字段查询、K 线/财务/因子远程查询。

### simulation-trading

**模拟交易**。下单买卖、持仓管理、成交查询、账户状态、资金快照。

---

## 相关平台功能（非技能）

以下功能通过 QuantBot 交互或前端页面访问，当前未封装为独立技能，但已纳入国际市场能力：

- **市场分析平台** — 大盘广度（涨跌家数）、资金流向（北向/主力/申万 Sankey 图）、申万行业热力图、板块轮动、规则引擎（`electron/src/features/market-analysis/`）
- **投研分析（TradingAgents）** — 多 Agent A 股/港股/美股研究报告生成
- **智能策略向导** — 条件选股 → 股票池 → 策略参数 → 验证保存 四步流程

---

## 技能开发约定

新增技能时：

1. 在 `.claude/skills/<skill-name>/` 下创建 `SKILL.md`
2. `SKILL.md` 顶部 YAML frontmatter 必须包含 `name` 和 `description`（description 含触发词，供 AI 意图识别）
3. 内容按「认证 → 端点 → 示例」组织，所有 API 统一走 `/api/v1` 前缀
4. 涉及市场的操作，标注市场参数（CN/HK/US/CRYPTO/FUTURES）
5. 打包进 `quantmind-operations-skill.zip`（保持目录结构 `.claude/skills/<name>/`）
