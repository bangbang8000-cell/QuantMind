---
name: stock-market-analysis
description: "股票市场深度数据分析与导出 — 全市场信号扫描、行业轮动、个股全维度分析、数据挖掘、CSV/Excel 导出。在 QuantBot / Claude Code 中分析股票市场、挖掘机会、导出分析数据、生成选股/投研报告时使用。触发词：分析市场、数据分析、数据挖掘、全市场扫描、行业轮动、导出数据、导出CSV、生成报告、投研分析、深度分析、挖掘机会"
---

# 股票市场深度数据分析与导出

基于 QuantDB 全量数据（K线/财务/估值/技术/315维因子）的股票市场深度分析 + 数据导出技能。

## 认证

```bash
BASE=http://127.0.0.1:8000
TOKEN=$(curl -s -X POST $BASE/api/v1/auth/login -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"admin123","tenant_id":"default"}' \
  | python3 -c "import sys,json; print(json.load(sys.stdin).get('access_token',''))")
AUTH="Authorization: Bearer $TOKEN"
CT="Content-Type: application/json"
```

## 1. 全市场信号扫描（选股）

### 1.1 每日选股信号
```bash
# 全市场扫描：11000+ 信号 → 精简候选
curl -s -H "$AUTH" "$BASE/api/v1/selection/daily"
# 返回: {status, meta:{trade_date, total_signals, strategy_config}, candidates, industry_signals}
# candidates 每项: {symbol, score, industry, trend, buy_reason, warnings}

# 指定策略
curl -s -H "$AUTH" "$BASE/api/v1/selection/daily?strategy=aggressive"
curl -s -H "$AUTH" "$BASE/api/v1/selection/daily?strategy=conservative"
curl -s -H "$AUTH" "$BASE/api/v1/selection/daily?strategy=balanced"
```

### 1.2 选股历史
```bash
curl -s -H "$AUTH" "$BASE/api/v1/selection/history"
```

## 2. 行业轮动与板块分析

选股响应的 `industry_signals` 字段包含各行业强度信号（行业 Top1 分数均值、强行业数等），用于判断：
- **入场信号**：`industry_avg_top1 >= 0.09` 且强行业数 >= 2 → 可入场
- **谨慎**：强行业数不足
- **空仓观望**：无强行业

## 3. 个股全维度分析

### 3.1 投研平台个股特征（371 字段全量）
```bash
# 单只股票全维度特征（估值/技术/动量/波动/流动性/资金流/风格/行业/筹码/概念/微观结构/情绪）
curl -s -H "$AUTH" "$BASE/api/v1/research/features/600519.SH"
# 批量
curl -s -X POST -H "$AUTH" -H "$CT" "$BASE/api/v1/research/batch-features" \
  -d '{"symbols":["600519.SH","000858.SZ"]}'
# 投影模式（只取指定字段，响应小）
curl -s -X POST -H "$AUTH" -H "$CT" "$BASE/api/v1/research/batch-features" \
  -d '{"symbols":["600519.SH"],"fields":["pe","roe","momRet5d","volStd20","mainFlow"]}'
```

### 3.2 个股风险评分卡
```bash
# 单只风险评分（流动性/波动/趋势/过热/基本面/状态 6 维度）
curl -s -H "$AUTH" "$BASE/api/v1/risk/score/600519.SH"
# 批量
curl -s -X POST -H "$AUTH" -H "$CT" "$BASE/api/v1/risk/scores" \
  -d '{"symbols":["600519.SH","000858.SZ"]}'
```

### 3.3 个股历史推理分数
```bash
curl -s -H "$AUTH" "$BASE/api/v1/models/inference/stock/600519.SH/history?days=180"
```

### 3.4 K 线数据（120 日）
```bash
curl -s -H "$AUTH" "$BASE/api/v1/research/kline/600519.SH?days=120"
```

## 4. 全市场候选池分析（投研）

### 4.1 候选池概览
```bash
# 某次推理批次的候选池（含各股行业/概念/指数/分数）
curl -s -H "$AUTH" "$BASE/api/v1/research/overview?limit=100"
```

### 4.2 全池特征（universe）
```bash
# 指定 run 的全池数据（筛选/排序需要全池）
curl -s -H "$AUTH" "$BASE/api/v1/research/universe?run_id=run_20260805_xxx&limit=2000"
```

## 5. 量化数据挖掘（基于 QuantDB 因子）

```bash
# 查看可用数据集与字段（见 quantdb-sdk 技能）
curl -s -H "$AUTH" "$BASE/api/v1/admin/data-platform/quantdb/catalog"
curl -s -H "$AUTH" "$BASE/api/v1/admin/data-platform/quantdb/preview?dataset=l1_factors&limit=5"
curl -s -H "$AUTH" "$BASE/api/v1/admin/data-platform/quantdb/preview?dataset=l2_factors&limit=5"
```

### 深度挖掘路径（因子组合分析）
| 分析主题 | 用到的 QuantDB 字段 |
|---|---|
| **动量挖掘** | `mom_ret_5d/20d/60d, mom_ma_gap_*, mom_rsi_*` |
| **波动率掘金** | `vol_std_*, vol_atr_14, vol_parkinson_*, vol_gk_20` |
| **流动性异常** | `liq_volume_ratio_5/20, liq_obv_20, liq_mfi_14` |
| **资金流异动** | `flow_net_*, flow_large_net, flow_money_flow_index` |
| **筹码集中** | `chip_profit_ratio_*, chip_concentration_20, chip_peak_distance` |
| **行业强度** | `ind_strength_20/60, ind_rotation_speed_20, ind_crowding_20` |
| **概念热度** | `concept_hot_score, concept_momentum_top3, concept_leader_score` |
| **微观结构** | `micro_vpin_*, micro_pin, micro_order_flow_toxicity, micro_kyle_lambda` |

## 6. 数据导出（CSV / Excel）

### 6.1 导出选股候选 CSV
```bash
# 取选股结果 → 转换 CSV
curl -s -H "$AUTH" "$BASE/api/v1/selection/daily" -o /tmp/selection.json
python3 <<'EOF'
import json, csv
d = json.load(open('/tmp/selection.json')).get('data', {})
cands = d.get('candidates', [])
with open('/tmp/selection.csv', 'w', newline='', encoding='utf-8-sig') as f:
    w = csv.writer(f)
    w.writerow(['代码','名称','分数','行业','趋势','买入理由'])
    for c in cands:
        w.writerow([c.get('symbol'), c.get('name'), round(c.get('score',0),4), c.get('industry'), c.get('trend'), c.get('buy_reason')])
print(f'导出 {len(cands)} 只选股 → /tmp/selection.csv')
EOF
```

### 6.2 导出个股全维度特征 CSV
```bash
curl -s -H "$AUTH" "$BASE/api/v1/research/features/600519.SH" -o /tmp/stock_features.json
python3 <<'EOF'
import json
d = json.load(open('/tmp/stock_features.json')).get('data', {})
rows = []
for cat, fields in d.items():
    if isinstance(fields, dict):
        for k, v in fields.items():
            rows.append([cat, k, v])
with open('/tmp/stock_features.csv', 'w', newline='', encoding='utf-8-sig') as f:
    w = csv.writer(f)
    w.writerow(['类别','字段','值'])
    for r in rows: w.writerow(r)
print(f'导出 {len(rows)} 个字段 → /tmp/stock_features.csv')
EOF
```

### 6.3 导出批量股票对比 CSV
```bash
curl -s -X POST -H "$AUTH" -H "$CT" "$BASE/api/v1/research/batch-features" \
  -d '{"symbols":["600519.SH","000858.SZ","601318.SH"],"fields":["pe","pb","roe","totalMv","momRet20d","volStd20","mainFlow"]}' \
  -o /tmp/batch_features.json
python3 <<'EOF'
import json, csv
d = json.load(open('/tmp/batch_features.json')).get('data', {}).get('items', [])
with open('/tmp/stock_compare.csv', 'w', newline='', encoding='utf-8-sig') as f:
    w = csv.writer(f)
    if d:
        w.writerow(['代码'] + list(d[0].get('values', {}).keys()))
        for it in d:
            w.writerow([it.get('symbol')] + list(it.get('values', {}).values()))
print(f'导出 {len(d)} 只股票对比 → /tmp/stock_compare.csv')
EOF
```

### 6.4 导出风险评分卡 CSV
```bash
curl -s -X POST -H "$AUTH" -H "$CT" "$BASE/api/v1/risk/scores" \
  -d '{"symbols":["600519.SH","000858.SZ","601318.SH"]}' -o /tmp/risk_batch.json
python3 <<'EOF'
import json, csv
d = json.load(open('/tmp/risk_batch.json')).get('data', {}).get('items', {})
with open('/tmp/risk_scores.csv', 'w', newline='', encoding='utf-8-sig') as f:
    w = csv.writer(f)
    w.writerow(['代码','风险分','等级','否决','否决原因','日期'])
    for sym, v in d.items():
        w.writerow([sym, v.get('risk_score'), v.get('risk_level'), v.get('veto'), ';'.join(v.get('veto_reasons') or []), v.get('trade_date')])
print(f'导出 {len(d)} 只风险评分 → /tmp/risk_scores.csv')
EOF
```

## 7. 综合投研报告流程（推荐）

当用户要求"深度分析"某股票/行业/全市场时：

1. **全市场扫描**：`/selection/daily` 看当前机会（11000+ 信号）
2. **行业判断**：从选股响应的 `industry_signals` 看板块强弱
3. **个股深挖**：`/research/features/{symbol}` 拿 371 字段全维度
4. **风险审查**：`/risk/score/{symbol}` 6 维度评分
5. **模型交叉验证**：`/models/inference/stock/{symbol}/history` 看推理分数趋势
6. **新闻印证**：`/news/articles?tickers=xxx` 看利好利空
7. **K线确认**：`/research/kline/{symbol}` 看走势
8. **导出报告**：按需导出 CSV（选股/特征对比/风险评分）

## 8. 相关技能联动

- **[[quantdb-sdk]]** — QuantDB 数据源（Key 配置、28 数据集、字段清单）
- **[[smart-strategy-stock-picking]]** — 条件选股（183 字段 DSL 筛选）
- **[[quantmind-operations]]** — 模型训练/推理/RSS 新闻
- **[[rd-agent-factor-mining]]** — 因子挖掘深化分析维度

## 9. 常见问题

| 现象 | 处理 |
|---|---|
| 选股 candidates 空 | 检查 `total_signals`，可能当天无满足阈值信号 |
| 个股特征空 | 确认 symbol 格式（600519.SH），用 `/research/batch-features` 批量试 |
| 导出乱码 | CSV 用 `utf-8-sig` 编码（已内置 BOM） |
| 需要更多字段 | 用 `/research/features` 全量（371 字段）而非投影 |
