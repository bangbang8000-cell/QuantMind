---
name: trading-agents
description: "投研分析（TradingAgents）— 多 Agent 研究报告生成、7 分析师、多空辩论、风险评估。在 QuantBot / Claude Code 中生成股票/行业/市场投研报告、深度研究报告、AI 分析师分析时使用。触发词：投研分析、研究报告、生成报告、深度研报、TradingAgents、分析师、多Agent分析、股票研究报告"
---

# 投研分析（TradingAgents）技能

多 Agent 投研分析管线：7 个 AI 分析师从技术/情绪/新闻/基本面/政策/游资/解禁多维度分析，经质量门控、多空辩论、交易决策、风控评估，生成最终研究报告。支持 **A股/港股/美股/区块链/期货** 五市场。

## 认证

```bash
BASE=http://127.0.0.1:8000
TOKEN=$(curl -s -X POST $BASE/api/v1/auth/login -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"admin123","tenant_id":"default"}' \
  | python3 -c "import sys,json; print(json.load(sys.stdin).get('access_token',''))")
AUTH="Authorization: Bearer $TOKEN"
CT="Content-Type: application/json"
```

## 1. 启动投研分析

```bash
curl -s -X POST -H "$AUTH" -H "$CT" "$BASE/api/v1/trading-agents/analyze" \
  -d '{
    "symbol": "600519.SH",
    "market": "CN",
    "analysis_type": "stock"       # stock / industry / market
  }'
# 返回: {analysis_id, status: "running"}
```

**参数**：
| 字段 | 说明 |
|---|---|
| `symbol` | 股票代码（600519.SH / 000858.SZ / 港股/美股 ticker） |
| `market` | CN / HK / US / CRYPTO / FUTURES |
| `analysis_type` | stock（个股）/ industry（行业）/ market（市场） |

**数据来源**：`data_vendors` 用 `quantmind_local` 读本地 QuantDB parquet，各市场回退 vendor（CN:a_stock / HK:hk_stock / US:us_stock / CRYPTO:crypto / FUTURES:futures）。

## 2. 轮询分析进度

```bash
# 进度（0-100%，12 阶段）
curl -s -H "$AUTH" "$BASE/api/v1/trading-agents/progress/{analysis_id}"
# 返回: {progress, stage, stage_name, message}
```

**12 阶段管线**：
1. 技术分析 → 2. 市场情绪 → 3. 新闻舆情 → 4. 基本面 → 5. 政策 → 6. 游资 → 7. 解禁 → 8. 质量门控 → 9. 多空辩论 → 10. 交易决策 → 11. 风控评估 → 12. 最终决策

## 3. 获取研究报告

```bash
# 分析报告（结构化 JSON）
curl -s -H "$AUTH" "$BASE/api/v1/trading-agents/report/{analysis_id}"

# 下载报告（JSON 文件）
curl -s -H "$AUTH" "$BASE/api/v1/trading-agents/download/{analysis_id}" -o report.json
```

**报告结构**：技术面 / 情绪面 / 新闻面 / 基本面 / 政策面 / 游资面 / 解禁面 各分析师观点 + 多空辩论 + 交易决策（买卖/仓位）+ 风控评估（风险等级/止损建议）。

## 4. 分析历史 / 停止 / 配置

```bash
# 历史分析记录
curl -s -H "$AUTH" "$BASE/api/v1/trading-agents/history"

# 停止正在运行的分析
curl -s -X POST -H "$AUTH" -H "$CT" "$BASE/api/v1/trading-agents/stop" \
  -d '{"analysis_id":"xxx"}'

# 查看管线配置（模型/市场设置）
curl -s -H "$AUTH" "$BASE/api/v1/trading-agents/config"
```

## 5. 实战流程（推荐）

当用户要求"生成投研报告 / 分析某只股票"时：
1. **选标的**：确认 symbol + market
2. **启动分析**：`/trading-agents/analyze` POST
3. **轮询进度**：`/progress/{id}` 每 10s 查一次（12 阶段通常 1-3 分钟）
4. **取报告**：`/report/{id}` 拿结构化结论
5. **交叉验证**：结合 [[stock-market-analysis]] 的量化因子 + [[quantdb-sdk]] 的数据

## 6. 相关技能

- **[[stock-market-analysis]]** — 量化因子深度分析（371 字段 + 风险评分）
- **[[batch-inference-analysis]]** — 模型推理信号选股
- **[[quantmind-operations]]** — RSS 新闻、模型推理
- **[[quantdb-sdk]]** — QuantDB 数据查询

## 7. 常见问题

| 现象 | 处理 |
|---|---|
| analyze 超时 | 减小分析范围，先看 `/config` 确认模型配置 |
| 进度卡住 | 检查引擎服务健康，用 `/stop` 停止后重试 |
| 报告为空 | 确认 analysis_id 状态 completed，等进度 100% |
| 本地数据缺失 | 该市场未同步，先跑对应 `*_daily_sync.py` 或数据管理页同步 |
