#!/bin/bash
# QuantMind L2高频因子计算 - 合并引擎v2
# 单次读取CSV, 一次性计算215维因子
# 使用方法: bash run_all_v2.sh [日期] [7z文件路径]
# 示例: bash run_all_v2.sh 20260422 /quantmind/baidudesk/20260422.7z

set -e

DATE=${1:-20260424}
ARCHIVE=${2:-/quantmind/baidudesk/${DATE}.7z}
SCRIPT_DIR=/quantmind/scripts/hf_factors
OUTPUT_DIR=/quantmind/db/hf_test_${DATE}
SHM_DIR=/dev/shm/hf_data

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'
log() { echo -e "${GREEN}[$(date '+%H:%M:%S')]${NC} $1"; }
warn() { echo -e "${YELLOW}[$(date '+%H:%M:%S')] WARN:${NC} $1"; }

# 步骤1: 检查环境
log "===== 步骤1: 检查环境 ====="
[ ! -f "$ARCHIVE" ] && { echo "ERROR: $ARCHIVE 不存在"; exit 1; }
log "数据文件: $ARCHIVE ($(du -h $ARCHIVE | cut -f1))"
MEM_AVAIL=$(free -g | awk '/Mem:/ {print $7}')
log "可用内存: ${MEM_AVAIL}GB"
SHM_SIZE=$(df -BG /dev/shm | awk 'NR==2 {print $2}' | tr -d 'G')
log "/dev/shm大小: ${SHM_SIZE}GB"
mkdir -p "$OUTPUT_DIR"
log "输出目录: $OUTPUT_DIR"

# 步骤2: 生成A股代码列表
log "===== 步骤2: 生成A股代码列表 ====="
CODE_FILE=/tmp/a_share_codes_${DATE}.txt
cd "$SCRIPT_DIR"
python3 -c "
from hf_common import list_stocks
stocks = list_stocks()
with open('${CODE_FILE}','w') as f:
    for s in stocks:
        f.write(f'${DATE}/{s}/*\n')
print(f'{len(stocks)} A股')
" 2>&1 | tail -1

# 步骤3: 解压到/dev/shm
log "===== 步骤3: 解压数据到/dev/shm ====="
rm -rf $SHM_DIR 2>/dev/null
mkdir -p $SHM_DIR
time 7z x "$ARCHIVE" @${CODE_FILE} -o$SHM_DIR -y -mmt=64 2>/dev/null
N_STOCKS=$(ls $SHM_DIR/$DATE/ 2>/dev/null | wc -l)
SHM_SIZE_USED=$(du -sh $SHM_DIR 2>/dev/null | cut -f1)
log "解压完成: ${N_STOCKS} 只股票, 占用 ${SHM_SIZE_USED}"
[ "$N_STOCKS" -lt 4000 ] && { echo "ERROR: 解压股票数<4000"; exit 1; }

# 步骤4: 配置脚本参数
log "===== 步骤4: 配置脚本参数 ====="
HF_COMMON=$SCRIPT_DIR/hf_common.py
cp "$HF_COMMON" "${HF_COMMON}.bak"
sed -i "s|DATE_PREFIX = \".*\"|DATE_PREFIX = \"${DATE}\"|" "$HF_COMMON"
sed -i "s|ARCHIVE = \".*\"|ARCHIVE = \"${ARCHIVE}\"|" "$HF_COMMON"
sed -i "s|OUTPUT_DIR = Path(\"/quantmind/db/hf_test_[0-9]*\")|OUTPUT_DIR = Path(\"/quantmind/db/hf_test_${DATE}\")|" "$HF_COMMON"

# 同步配置到hf_compute_all.py
sed -i "s|ARCHIVE = \".*\"|ARCHIVE = \"${ARCHIVE}\"|" "$SCRIPT_DIR/hf_compute_all.py"
sed -i "s|DATE_PREFIX = \".*\"|DATE_PREFIX = \"${DATE}\"|" "$SCRIPT_DIR/hf_compute_all.py"
sed -i "s|OUTPUT_DIR = Path(\"/quantmind/db/hf_test_[0-9]*\")|OUTPUT_DIR = Path(\"/quantmind/db/hf_test_${DATE}\")|" "$SCRIPT_DIR/hf_compute_all.py"
log "已更新配置: DATE=$DATE, ARCHIVE=$ARCHIVE, OUTPUT_DIR=$OUTPUT_DIR"

# 步骤5: 合并计算215维因子
log "===== 步骤5: 合并计算215维因子 (单次读取) ====="
cd "$SCRIPT_DIR"
python3 -u -c "
import warnings; warnings.filterwarnings('ignore')
from hf_compute_all import run_all
run_all(limit=None)
" 2>&1

# 步骤6: 清理
log "===== 步骤6: 清理临时文件 ====="
rm -rf $SHM_DIR
mv "${HF_COMMON}.bak" "$HF_COMMON" 2>/dev/null || true
rm -f $CODE_FILE
log "===== 全部完成 ====="
log "结果文件: ${OUTPUT_DIR}/hf_factors_all.parquet"
