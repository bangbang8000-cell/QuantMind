"""
2.3 资金流与不平衡 (Money Flow & Imbalance) - 30维
数据源: deal (Side: 0=主动买入, 1=主动卖出)
金额=price×volume, 分单: >=100万=特大, 20~100万=大, 5~20万=中, <5万=小
"""
import numpy as np, pandas as pd
from hf_common import *

def compute(stock_dir):
    deal = load_deal(stock_dir)
    if deal.empty: return None
    o = {'wind_code': str(stock_dir).split('/')[-1]}
    d = deal[deal['price']>0].copy()
    if d.empty: return None
    d = d[d['side'].isin([0,1])].copy()
    if d.empty: return None

    buy = (d['side']==0).astype(float)
    sell = (d['side']==1).astype(float)
    amt = d['amount']
    vol = d['volume']
    total_amt = float(amt.sum())
    total_vol = float(vol.sum())

    # flow_net_amount [1维]
    b_amt = float((amt*buy).sum()); s_amt = float((amt*sell).sum())
    o['flow_net_amount'] = b_amt - s_amt
    # flow_buy_amount / flow_sell_amount [2维]
    o['flow_buy_amount'] = b_amt; o['flow_sell_amount'] = s_amt
    # flow_net_ratio [1维]
    o['flow_net_ratio'] = safe_div(b_amt-s_amt, b_amt+s_amt)
    # flow_buy_ratio / flow_sell_ratio [2维]
    n_total = len(d)
    o['flow_buy_ratio'] = safe_div(int(buy.sum()), n_total)
    o['flow_sell_ratio'] = safe_div(int(sell.sum()), n_total)

    # 分单
    xl = (amt >= 1_000_000).astype(float)
    lg = ((amt>=200_000) & (amt<1_000_000)).astype(float)
    md = ((amt>=50_000) & (amt<200_000)).astype(float)
    sm = (amt < 50_000).astype(float)

    # flow_super/large/medium/small_net [4维]
    b_xl=float((amt*buy*xl).sum()); s_xl=float((amt*sell*xl).sum())
    b_lg=float((amt*buy*lg).sum()); s_lg=float((amt*sell*lg).sum())
    b_md=float((amt*buy*md).sum()); s_md=float((amt*sell*md).sum())
    b_sm=float((amt*buy*sm).sum()); s_sm=float((amt*sell*sm).sum())
    o['flow_super_net'] = b_xl-s_xl
    o['flow_large_net'] = b_lg-s_lg
    o['flow_medium_net'] = b_md-s_md
    o['flow_small_net'] = b_sm-s_sm

    # flow_super/large/medium/small_ratio [4维]
    o['flow_super_ratio'] = safe_div(b_xl-s_xl, b_xl+s_xl)
    o['flow_large_ratio'] = safe_div(b_lg-s_lg, b_lg+s_lg)
    o['flow_medium_ratio'] = safe_div(b_md-s_md, b_md+s_md)
    o['flow_small_ratio'] = safe_div(b_sm-s_sm, b_sm+s_sm)

    # flow_large_pct [1维]
    o['flow_large_pct'] = safe_div(float((amt*(xl+lg)).sum()), total_amt)

    # flow_imbalance_volume/amount/count [3维]
    b_vol=float((vol*buy).sum()); s_vol=float((vol*sell).sum())
    # flow_imbalance_volume [1维]
    o['flow_imbalance_volume'] = safe_div(b_vol-s_vol, b_vol+s_vol)

    # flow_imbalance_open/mid_am/mid_pm/close [4维]
    d_open = d[d['seconds'].between(*SEG_OPEN)]
    d_mid_am = d[d['seconds'].between(36000,41400)]
    d_mid_pm = d[d['seconds'].between(46800,52200)]
    d_close = d[d['seconds'].between(*SEG_CLOSE)]
    for seg_df, name in [(d_open,'open'),(d_mid_am,'mid_am'),(d_mid_pm,'mid_pm'),(d_close,'close')]:
        if seg_df.empty: o[f'flow_imbalance_{name}'] = np.nan; continue
        sb = (seg_df['side']==0).astype(float); ss = (seg_df['side']==1).astype(float)
        sa = (seg_df['amount']).values
        o[f'flow_imbalance_{name}'] = safe_div(float((sa*sb).sum())-float((sa*ss).sum()), float(sa.sum()))

    # flow_imbalance_autocorr [1维]
    d_sorted = d.sort_values('seconds').copy()
    d_sorted['bucket'] = (d_sorted['seconds']//300)*300
    d_sorted['buy_amt'] = d_sorted['amount'] * (d_sorted['side']==0)
    d_sorted['sell_amt'] = d_sorted['amount'] * (d_sorted['side']==1)
    dg = d_sorted.groupby('bucket')
    buy_total = dg['buy_amt'].sum()
    sell_total = dg['sell_amt'].sum()
    amt_total = dg['amount'].sum()
    imb_5min = ((buy_total - sell_total) / amt_total).dropna()
    if len(imb_5min) > 1:
        o['flow_imbalance_autocorr'] = float(imb_5min.autocorr(lag=1)) if imb_5min.autocorr(lag=1) == imb_5min.autocorr(lag=1) else np.nan
    else:
        o['flow_imbalance_autocorr'] = np.nan

    # flow_imbalance_revert_speed [1维]
    if len(imb_5min) > 2:
        high_imb = imb_5min[imb_5min > 0.3]
        reverts = []
        for idx in high_imb.index:
            pos = imb_5min.index.get_loc(idx)
            for j in range(pos+1, len(imb_5min)):
                if imb_5min.iloc[j] < 0.1:
                    reverts.append(imb_5min.index[j]-idx)
                    break
        o['flow_imbalance_revert_speed'] = float(np.mean(reverts)/300) if reverts else np.nan
    else:
        o['flow_imbalance_revert_speed'] = np.nan

    # flow_consistency [1维]
    sides = d.sort_values('seconds')['side'].values
    if len(sides) > 1:
        same = np.sum(sides[1:] == sides[:-1])
        o['flow_consistency'] = safe_div(int(same), len(sides)-1)
    else:
        o['flow_consistency'] = np.nan

    # flow_money_flow_index [1维]
    # 上涨正资金 - 下跌正资金
    d_sorted2 = d.sort_values('seconds').copy()
    if len(d_sorted2) > 1:
        price_diff = d_sorted2['price'].diff().fillna(0)
        up = (price_diff > 0).astype(float)
        down = (price_diff < 0).astype(float)
        pos_mf = float((d_sorted2['amount']*up).sum())
        neg_mf = float((d_sorted2['amount']*down).sum())
        o['flow_money_flow_index'] = safe_div(pos_mf - neg_mf, pos_mf + neg_mf)
    else:
        o['flow_money_flow_index'] = np.nan

    # flow_big_trade_ratio [1维]
    o['flow_big_trade_ratio'] = safe_div(float((amt>=500000).sum()), n_total)

    return o

if __name__ == '__main__':
    run_script(compute, 'factor_2_3_flow', limit=None)
