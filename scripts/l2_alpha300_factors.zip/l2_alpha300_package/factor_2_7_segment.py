"""
2.7 分时段特征 (Time-segment Features) - 30维
数据源: snapshot+deal按时段切片
时段: T1=集合竞价, T2=开盘, T3~T4=上午, T5~T6=下午, T7=尾盘, T8=收盘集合
"""
import numpy as np, pandas as pd
from hf_common import *

# 8个时段定义
SEGMENTS = [
    ('T1', 33300, 33900),   # 09:15-09:25 集合竞价(不含结果)
    ('T2', 34200, 36000),   # 09:30-10:00 开盘
    ('T3', 36000, 39600),   # 10:00-11:00
    ('T4', 39600, 41400),   # 11:00-11:30
    ('T5', 46800, 48600),   # 13:00-13:30
    ('T6', 48600, 52200),   # 13:30-14:30
    ('T7', 52200, 53820),   # 14:30-14:57 尾盘
    ('T8', 53820, 54000),   # 14:57-15:00 收盘集合
]

def compute(stock_dir):
    snap = load_snapshot(stock_dir)
    deal = load_deal(stock_dir)
    if snap.empty and deal.empty: return None
    o = {'wind_code': str(stock_dir).split('/')[-1]}
    total_vol = 0
    if not snap.empty: total_vol += float(snap['volume'].sum())
    if not deal.empty: total_vol += float(deal['volume'].sum())
    if total_vol <= 0: return None

    # micro_zone_vol_ratio_T1~T8 [8维]
    for name, lo, hi in SEGMENTS:
        seg_vol = 0
        if not snap.empty:
            seg_vol += float(snap[snap['seconds'].between(lo,hi)]['volume'].sum())
        if not deal.empty:
            seg_vol += float(deal[deal['seconds'].between(lo,hi)]['volume'].sum())
        o[f'micro_zone_vol_ratio_{name}'] = safe_div(seg_vol, total_vol)

    # micro_zone_rv_ratio_AM/PM/opening/closing [4维]
    for seg, name in [(SEG_AM,'AM'),(SEG_PM,'PM'),(SEG_OPEN,'open'),(SEG_CLOSE,'close')]:
        if not deal.empty:
            d = deal[(deal['price']>0)&(deal['seconds'].between(*seg))].copy()
        elif not snap.empty:
            d = snap[(snap['price']>0)&(snap['seconds'].between(*seg))].copy()
        else:
            o[f'micro_zone_rv_ratio_{name}'] = np.nan; continue
        if d.empty or len(d) < 2:
            o[f'micro_zone_rv_ratio_{name}'] = np.nan; continue
        d = d.sort_values('seconds')
        d['bucket'] = (d['seconds']//300)*300
        d['pv'] = d['price'] * d['volume']
        dg = d.groupby('bucket')
        vwap = (dg['pv'].sum() / dg['volume'].sum()).dropna()
        if len(vwap) >= 2:
            r = 100.0*np.log(vwap).diff().dropna()
            seg_rv = float((r**2).sum())
        else:
            seg_rv = 0.0
        # 全天RV
        if not deal.empty:
            d_all = deal[deal['price']>0].copy()
        else:
            d_all = snap[snap['price']>0].copy()
        d_all = d_all.sort_values('seconds')
        d_all['bucket'] = (d_all['seconds']//300)*300
        d_all['pv'] = d_all['price'] * d_all['volume']
        dg_all = d_all.groupby('bucket')
        vwap_all = (dg_all['pv'].sum() / dg_all['volume'].sum()).dropna()
        if len(vwap_all) >= 2:
            r_all = 100.0*np.log(vwap_all).diff().dropna()
            all_rv = float((r_all**2).sum())
        else:
            all_rv = np.nan
        o[f'micro_zone_rv_ratio_{name}'] = safe_div(seg_rv, all_rv) if all_rv and all_rv > 0 else np.nan

    # micro_zone_spread_ratio_open/mid/close [3维]
    if not snap.empty:
        df = snap[snap['ask_price1']>0].copy()
        df['mid'] = (df['ask_price1']+df['bid_price1'])/2
        df['qsp'] = (df['ask_price1']-df['bid_price1'])/df['mid']
        all_qsp = float(df['qsp'].mean())
        for seg, name in [(SEG_OPEN,'open'),(SEG_MID,'mid'),(SEG_CLOSE,'close')]:
            seg_qsp = float(df[df['seconds'].between(*seg)]['qsp'].mean())
            o[f'micro_zone_spread_ratio_{name}'] = safe_div(seg_qsp, all_qsp) if all_qsp and all_qsp > 0 else np.nan
    else:
        o['micro_zone_spread_ratio_open'] = np.nan
        o['micro_zone_spread_ratio_mid'] = np.nan
        o['micro_zone_spread_ratio_close'] = np.nan

    # micro_open_gap [1维]
    if not snap.empty and not snap[snap['price']>0].empty:
        first_price = float(snap[snap['price']>0].iloc[0]['price'])
        pre_close = float(snap.iloc[0]['pre_close']) if snap.iloc[0]['pre_close']>0 else np.nan
        o['micro_open_gap'] = safe_div(first_price-pre_close, pre_close) if pre_close and pre_close > 0 else np.nan
    else:
        o['micro_open_gap'] = np.nan

    # micro_call_auction_vol_ratio [1维]
    if not snap.empty:
        # 使用扩大的窗口(含09:25结果快照, 因为集合竞价时段volume列为0)
        CA_FULL = (33300, 34000)
        ca_df = snap[snap['seconds'].between(*CA_FULL)]
        ca_vol = float(ca_df['volume'].sum())
        if ca_vol <= 0 and not ca_df.empty:
            ca_sorted = ca_df.sort_values('seconds')
            if 'cum_volume' in ca_sorted.columns:
                last_cum = float(ca_sorted['cum_volume'].iloc[-1]) if len(ca_sorted) > 0 else 0
                first_cum = float(ca_sorted['cum_volume'].iloc[0]) if len(ca_sorted) > 0 else 0
                ca_vol = max(last_cum - first_cum, 0)
        o['micro_call_auction_vol_ratio'] = safe_div(ca_vol, total_vol)
    else:
        o['micro_call_auction_vol_ratio'] = np.nan

    # micro_call_auction_depth_change [1维]
    if not snap.empty:
        ca_df = snap[snap['seconds'].between(*SEG_CALL_AUCTION)].sort_values('seconds')
        if len(ca_df) > 1:
            total_depth = ca_df[[f'bid_vol{i}' for i in range(1,11)]].sum(axis=1) + ca_df[[f'ask_vol{i}' for i in range(1,11)]].sum(axis=1)
            if len(total_depth) > 1:
                d0 = float(total_depth.iloc[0])
                d1 = float(total_depth.iloc[-1])
                o['micro_call_auction_depth_change'] = safe_div(d1 - d0, d0) if d0 and d0 != 0 else np.nan
            else:
                o['micro_call_auction_depth_change'] = np.nan
        else:
            o['micro_call_auction_depth_change'] = np.nan
    else:
        o['micro_call_auction_depth_change'] = np.nan

    # micro_close_auction_impact [1维]
    if not snap.empty:
        close_df = snap[snap['seconds'].between(*SEG_CLOSE)].sort_values('seconds')
        if len(close_df) >= 2:
            last_tick = float(close_df.iloc[-2]['price'])
            final = float(close_df.iloc[-1]['price'])
            o['micro_close_auction_impact'] = safe_div(final-last_tick, last_tick) if last_tick and last_tick > 0 else np.nan
        else:
            o['micro_close_auction_impact'] = np.nan
    else:
        o['micro_close_auction_impact'] = np.nan

    # micro_close_squeeze [1维]
    if not deal.empty:
        d = deal[deal['price']>0].sort_values('seconds').copy()
        if len(d) >= 30:
            ret_10 = d.tail(10)['price'].pct_change().sum()
            ret_30 = d.tail(30)['price'].pct_change().sum()
            if ret_30 and ret_30 != 0:
                o['micro_close_squeeze'] = safe_div(ret_10-ret_30, ret_30)
            else:
                o['micro_close_squeeze'] = 0.0  # 尾盘无波动, 无拉升/打压
        else:
            o['micro_close_squeeze'] = np.nan
    else:
        o['micro_close_squeeze'] = np.nan

    # micro_lunch_break_gap [1维]
    if not snap.empty:
        am_close = snap[snap['seconds']<41400].sort_values('seconds')
        pm_open = snap[snap['seconds']>=46800].sort_values('seconds')
        if not am_close.empty and not pm_open.empty:
            am_price = float(am_close.iloc[-1]['price'])
            pm_price = float(pm_open.iloc[0]['price'])
            o['micro_lunch_break_gap'] = safe_div(pm_price-am_price, am_price) if am_price and am_price > 0 else np.nan
        else:
            o['micro_lunch_break_gap'] = np.nan
    else:
        o['micro_lunch_break_gap'] = np.nan

    # micro_zone_vpin_open [1维]
    if not deal.empty:
        d_open = deal[(deal['price']>0)&(deal['volume']>0)&(deal['side'].isin([0,1]))&(deal['seconds'].between(*SEG_OPEN))].copy()
        if not d_open.empty and len(d_open) > 10:
            o['micro_zone_vpin_open'] = _vpin_simple(d_open, 8)
        else:
            o['micro_zone_vpin_open'] = np.nan
    else:
        o['micro_zone_vpin_open'] = np.nan

    # micro_zone_imbalance_am/pm [2维]
    if not deal.empty:
        d = deal[(deal['price']>0)&(deal['side'].isin([0,1]))].copy()
        for seg, name in [(SEG_AM,'am'),(SEG_PM,'pm')]:
            seg_d = d[d['seconds'].between(*seg)]
            if seg_d.empty:
                o[f'micro_zone_imbalance_{name}'] = np.nan; continue
            b = float(seg_d.loc[seg_d['side']==0,'amount'].sum())
            s = float(seg_d.loc[seg_d['side']==1,'amount'].sum())
            o[f'micro_zone_imbalance_{name}'] = safe_div(b-s, b+s)
    else:
        o['micro_zone_imbalance_am'] = np.nan
        o['micro_zone_imbalance_pm'] = np.nan

    # micro_zone_morning_evening_ratio [1维]
    if not deal.empty:
        am_amt = float(deal[deal['seconds'].between(*SEG_AM)]['amount'].sum())
        pm_amt = float(deal[deal['seconds'].between(*SEG_PM)]['amount'].sum())
        o['micro_zone_morning_evening_ratio'] = safe_div(am_amt, pm_amt) if pm_amt and pm_amt > 0 else np.nan
    else:
        o['micro_zone_morning_evening_ratio'] = np.nan

    # micro_zone_distribution [1维]
    if not snap.empty:
        seg_vols = []
        for name, lo, hi in SEGMENTS:
            seg_vols.append(float(snap[snap['seconds'].between(lo,hi)]['volume'].sum()))
        total = sum(seg_vols)
        if total > 0:
            p = np.array(seg_vols)/total
            p = p[p>0]
            o['micro_zone_distribution'] = float(-(p*np.log(p)).sum())
        else:
            o['micro_zone_distribution'] = np.nan
    else:
        o['micro_zone_distribution'] = np.nan

    return o

def _vpin_simple(d, n):
    total_vol = d['volume'].sum()
    if total_vol <= 0: return np.nan
    bucket_size = total_vol / n
    d = d.sort_values('seconds').copy()
    d['cumvol'] = d['volume'].cumsum()
    d['bucket'] = (d['cumvol']/bucket_size).astype(int)
    grp = d.groupby('bucket')
    bv = grp.apply(lambda g: float(g.loc[g['side']==0,'volume'].sum()))
    sv = grp.apply(lambda g: float(g.loc[g['side']==1,'volume'].sum()))
    imb = (bv-sv).abs()
    tot = bv+sv
    valid = tot > 0
    if valid.sum() == 0: return np.nan
    return float(imb[valid].sum()/tot[valid].sum())

if __name__ == '__main__':
    run_script(compute, 'factor_2_7_segment', limit=None)
