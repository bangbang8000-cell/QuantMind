"""
2.11 信息不对称与毒性补充 (Adverse Selection & Toxicity Supplement) - 19维
数据源: deal + snapshot + order
补充200维L2因子到完整200维(补回删除的19个冗余因子)
"""
import numpy as np, pandas as pd
from hf_common import *

def compute(stock_dir):
    deal = load_deal(stock_dir)
    if deal.empty: return None
    snap = load_snapshot(stock_dir)
    order = load_order(stock_dir)
    o = {'wind_code': str(stock_dir).split('/')[-1]}
    
    d = deal.sort_values('seconds').reset_index(drop=True)
    prices = d['price'].values
    vols = d['volume'].values
    amts = d['amount'].values
    sides = d['side'].values  # 0=buy, 1=sell
    secs = d['seconds'].values
    n = len(d)
    
    if n < 10:
        for k in _all_keys():
            o[k] = np.nan
        return o
    
    # ==================== VPIN补充(5维) ====================
    
    # 1. micro_vpin_100: N=100等量分桶VPIN
    bucket_size = max(n // 100, 1)
    n_buckets = n // bucket_size
    if n_buckets >= 5:
        vpin_100 = []
        for i in range(n_buckets):
            chunk = sides[i*bucket_size:(i+1)*bucket_size]
            buy = (chunk == 0).sum()
            sell = (chunk == 1).sum()
            vpin_100.append(abs(buy - sell) / len(chunk))
        o['micro_vpin_100'] = float(np.mean(vpin_100))
    else:
        o['micro_vpin_100'] = np.nan
    
    # 2. micro_vpin_kyle: Kyle调整VPIN
    # 用signed order flow的绝对值占比
    signed_flow = np.where(sides == 0, vols, -vols)
    cum_abs = np.abs(signed_flow).cumsum()
    total_abs = cum_abs[-1]
    if total_abs > 0 and n >= 20:
        # 分20桶, 计算每桶的不平衡
        bs = max(n // 20, 1)
        imb = []
        for i in range(n // bs):
            chunk = signed_flow[i*bs:(i+1)*bs]
            imb.append(abs(chunk.sum()) / (np.abs(chunk).sum() + 1e-10))
        o['micro_vpin_kyle'] = float(np.mean(imb))
    else:
        o['micro_vpin_kyle'] = np.nan
    
    # 3. micro_vpin_quantile_ratio: 高毒性时段占比(VPIN>0.5)
    # 用N=50桶计算VPIN序列
    bs50 = max(n // 50, 1)
    vpin_series = []
    for i in range(n // bs50):
        chunk = sides[i*bs50:(i+1)*bs50]
        buy = (chunk == 0).sum()
        sell = (chunk == 1).sum()
        vpin_series.append(abs(buy - sell) / len(chunk))
    if vpin_series:
        vpin_arr = np.array(vpin_series)
        o['micro_vpin_quantile_ratio'] = float((vpin_arr > 0.5).sum() / len(vpin_arr))
    else:
        o['micro_vpin_quantile_ratio'] = np.nan
    
    # 4. micro_vpin_tail_risk: VPIN尾部风险(95分位VPIN)
    if vpin_series:
        o['micro_vpin_tail_risk'] = float(np.percentile(vpin_series, 95))
    else:
        o['micro_vpin_tail_risk'] = np.nan
    
    # 5. micro_vpin_entropy: VPIN熵(不确定性)
    if vpin_series:
        v = np.array(vpin_series)
        v_norm = v / (v.sum() + 1e-10)
        v_norm = v_norm[v_norm > 0]
        o['micro_vpin_entropy'] = float(-(v_norm * np.log(v_norm)).sum()) if len(v_norm) > 0 else np.nan
    else:
        o['micro_vpin_entropy'] = np.nan
    
    # ==================== 逆向选择成本(4维) ====================
    
    # 6. micro_adverse_selection: 逆向选择成本
    # = |成交价 - 5秒后中间价| / 成交价
    if not snap.empty:
        snap_sorted = snap.sort_values('seconds')
        snap_secs = snap_sorted['seconds'].values
        snap_mid = ((snap_sorted['bid_price1'] + snap_sorted['ask_price1']) / 2).values
        adverse_costs = []
        for i in range(min(n, 500)):  # 采样前500笔
            t = secs[i]
            # 找5秒后的中间价
            idx = np.searchsorted(snap_secs, t + 5)
            if idx < len(snap_mid):
                future_mid = snap_mid[idx]
                if future_mid > 0:
                    adverse_costs.append(abs(prices[i] - future_mid) / prices[i])
        o['micro_adverse_selection'] = float(np.mean(adverse_costs)) if adverse_costs else np.nan
    else:
        o['micro_adverse_selection'] = np.nan
    
    # 7. micro_realized_spread: 已实现价差(实际逆向选择成本)
    # = (成交价 - 5秒后中间价) × 方向 / 成交价
    if not snap.empty and len(d) > 20:
        snap_sorted = snap.sort_values('seconds')
        snap_secs = snap_sorted['seconds'].values
        snap_mid = ((snap_sorted['bid_price1'] + snap_sorted['ask_price1']) / 2).values
        realized = []
        for i in range(min(n, 500)):
            t = secs[i]
            idx = np.searchsorted(snap_secs, t + 5)
            if idx < len(snap_mid):
                future_mid = snap_mid[idx]
                if future_mid > 0:
                    # 买方: 成交价 - 未来中间价, 卖方: 未来中间价 - 成交价
                    direction = 1 if sides[i] == 0 else -1
                    realized.append(direction * (prices[i] - future_mid) / prices[i])
        o['micro_realized_spread'] = float(np.mean(realized)) if realized else np.nan
    else:
        o['micro_realized_spread'] = np.nan
    
    # 8. micro_adverse_selection_cost: 逆向选择成本占比
    # = 逆向选择成本 / 有效价差
    if not snap.empty:
        esp = o.get('micro_adverse_selection', np.nan)
        snap_s = snap.sort_values('seconds')
        if esp is not None and esp == esp:
            avg_spread = float(np.nanmean((snap_s['ask_price1'] - snap_s['bid_price1']).values / 
                         np.where(((snap_s['bid_price1'] + snap_s['ask_price1']) / 2) > 0,
                                  ((snap_s['bid_price1'] + snap_s['ask_price1']) / 2), np.nan)))
            if avg_spread and avg_spread > 0:
                o['micro_adverse_selection_cost'] = float(esp / avg_spread)
            else:
                o['micro_adverse_selection_cost'] = np.nan
        else:
            o['micro_adverse_selection_cost'] = np.nan
    else:
        o['micro_adverse_selection_cost'] = np.nan
    
    # 9. micro_spread_decomposition: 价差分解(逆向选择占比)
    # 逆向选择价差 = 2×|成交价-未来中间价|, 存货价差 = 有效价差 - 逆向选择价差
    if o.get('micro_realized_spread', np.nan) == o.get('micro_realized_spread', np.nan) and not snap.empty:
        avg_esp = float(np.mean(2 * np.abs(d['price'].values - 
                     ((snap.set_index('seconds').reindex(d['seconds'], method='ffill')['bid_price1'] +
                       snap.set_index('seconds').reindex(d['seconds'], method='ffill')['ask_price1']) / 2).values) /
                     d['price'].values)) if not snap.empty else np.nan
        rs = abs(o['micro_realized_spread'])
        if avg_esp and avg_esp > 0 and rs == rs:
            o['micro_spread_decomposition'] = float(rs / avg_esp)
        else:
            o['micro_spread_decomposition'] = np.nan
    else:
        o['micro_spread_decomposition'] = np.nan
    
    # ==================== 价格发现(2维) ====================
    
    # 10. micro_price_discovery: 价格发现效率
    # Hasbrouck信息份额近似: 成交对中间价变化的贡献比
    if not snap.empty and n > 20:
        snap_sorted = snap.sort_values('seconds')
        snap_mid = ((snap_sorted['bid_price1'] + snap_sorted['ask_price1']) / 2).values
        mid_returns = np.diff(snap_mid)
        mid_returns = mid_returns[np.isfinite(mid_returns)]
        if len(mid_returns) > 10:
            # 交易量加权回报的方差比 / 总方差
            trade_returns = np.diff(prices[:min(len(prices), len(mid_returns)+1)])
            trade_returns = trade_returns[np.isfinite(trade_returns)]
            min_len = min(len(mid_returns), len(trade_returns))
            if min_len > 5:
                var_mid = np.var(mid_returns[:min_len])
                var_trade = np.var(trade_returns[:min_len])
                if var_mid and var_mid > 0:
                    o['micro_price_discovery'] = float(var_trade / var_mid)
                else:
                    o['micro_price_discovery'] = np.nan
            else:
                o['micro_price_discovery'] = np.nan
        else:
            o['micro_price_discovery'] = np.nan
    else:
        o['micro_price_discovery'] = np.nan
    
    # 11. micro_information_share: 信息份额
    # 用成交方向预测后续回报的能力: corr(signed_vol, future_return)
    if n > 20:
        signed_vol = np.where(sides == 0, vols, -vols)[:-5]
        future_ret = np.diff(prices[5:])  # 5笔后的价格变化
        min_len = min(len(signed_vol), len(future_ret))
        if min_len > 10:
            corr = np.corrcoef(signed_vol[:min_len], future_ret[:min_len])[0, 1]
            o['micro_information_share'] = float(corr) if np.isfinite(corr) else np.nan
        else:
            o['micro_information_share'] = np.nan
    else:
        o['micro_information_share'] = np.nan
    
    # ==================== 毒性持续性(3维) ====================
    
    # 12. micro_toxicity_persistence: 毒性持续性(自相关)
    if vpin_series and len(vpin_series) > 3:
        v = np.array(vpin_series)
        if len(v) >= 4:
            corr = np.corrcoef(v[:-1], v[1:])[0, 1]
            o['micro_toxicity_persistence'] = float(corr) if np.isfinite(corr) else np.nan
        else:
            o['micro_toxicity_persistence'] = np.nan
    else:
        o['micro_toxicity_persistence'] = np.nan
    
    # 13. micro_vpin_hurst: VPIN序列Hurst指数
    if vpin_series and len(vpin_series) >= 10:
        v = np.array(vpin_series)
        # 简化Hurst: R/S法
        mean_v = v.mean()
        deviations = np.cumsum(v - mean_v)
        R = deviations.max() - deviations.min()
        S = v.std()
        if S and S > 0 and R > 0:
            o['micro_vpin_hurst'] = float(np.log(R / S) / np.log(len(v)))
        else:
            o['micro_vpin_hurst'] = np.nan
    else:
        o['micro_vpin_hurst'] = np.nan
    
    # 14. micro_vpin_conviction: VPIN信念度(连续高毒性时长)
    if vpin_series:
        v = np.array(vpin_series)
        threshold = np.median(v)
        above = v > threshold
        max_run = current_run = 0
        for a in above:
            if a:
                current_run += 1
                max_run = max(max_run, current_run)
            else:
                current_run = 0
        o['micro_vpin_conviction'] = float(max_run / len(v)) if len(v) > 0 else np.nan
    else:
        o['micro_vpin_conviction'] = np.nan
    
    # ==================== 不对称毒性(3维) ====================
    
    # 15. micro_toxicity_asymmetry: 毒性不对称(买方vs卖方成交占比差异)
    if n >= 50:
        bs = max(n // 20, 1)
        buy_ratios = []
        sell_ratios = []
        for i in range(n // bs):
            chunk_sides = sides[i*bs:(i+1)*bs]
            chunk_vols = vols[i*bs:(i+1)*bs]
            buy_vol = chunk_vols[chunk_sides == 0].sum()
            sell_vol = chunk_vols[chunk_sides == 1].sum()
            total = buy_vol + sell_vol
            if total > 0:
                buy_ratios.append(buy_vol / total)
                sell_ratios.append(sell_vol / total)
        if buy_ratios and sell_ratios:
            o['micro_toxicity_asymmetry'] = float(np.mean(buy_ratios) - np.mean(sell_ratios))
        else:
            o['micro_toxicity_asymmetry'] = np.nan
    else:
        o['micro_toxicity_asymmetry'] = np.nan
    
    # 16. micro_informed_ratio: 知情交易占比估计
    # 大单成交占比 × 方向集中度
    if n > 20:
        amt_threshold = np.percentile(amts, 90)
        large_trades = amts >= amt_threshold
        large_ratio = large_trades.sum() / n
        # 方向集中度
        large_sides = sides[large_trades]
        if len(large_sides) > 0:
            buy_pct = (large_sides == 0).sum() / len(large_sides)
            direction_concentration = abs(buy_pct - 0.5) * 2  # 0~1
            o['micro_informed_ratio'] = float(large_ratio * direction_concentration)
        else:
            o['micro_informed_ratio'] = np.nan
    else:
        o['micro_informed_ratio'] = np.nan
    
    # 17. micro_liquidity_mining: 流动性挖掘(大单毒性)
    # 大单(>90分位)成交后价格冲击 / 大单占比
    if n > 20:
        vol_threshold = np.percentile(vols, 90)
        large_idx = np.where(vols >= vol_threshold)[0]
        if len(large_idx) > 2:
            price_impacts = []
            for idx in large_idx:
                if idx + 5 < n:
                    impact = abs(prices[idx + 5] - prices[idx]) / prices[idx]
                    price_impacts.append(impact)
            if price_impacts:
                large_pct = len(large_idx) / n
                o['micro_liquidity_mining'] = float(np.mean(price_impacts) / large_pct) if large_pct > 0 else np.nan
            else:
                o['micro_liquidity_mining'] = np.nan
        else:
            o['micro_liquidity_mining'] = np.nan
    else:
        o['micro_liquidity_mining'] = np.nan
    
    # ==================== 委托流毒性(2维) ====================
    
    # 18. micro_order_imbalance_tox: 委托不平衡毒性
    if not order.empty:
        ot = order['order_type'].astype(str).str.upper()
        oc = order['order_code'].astype(str).str.upper()
        new_mask = ot == 'A'
        cancel_mask = ot == 'D'
        new_buy_vol = order.loc[new_mask & (oc == 'B'), 'volume'].sum()
        new_sell_vol = order.loc[new_mask & (oc == 'S'), 'volume'].sum()
        cancel_buy_vol = order.loc[cancel_mask & (oc == 'B'), 'volume'].sum()
        cancel_sell_vol = order.loc[cancel_mask & (oc == 'S'), 'volume'].sum()
        total_new = new_buy_vol + new_sell_vol
        total_cancel = cancel_buy_vol + cancel_sell_vol
        if total_new > 0 and total_cancel > 0:
            new_imb = abs(new_buy_vol - new_sell_vol) / total_new
            cancel_imb = abs(cancel_buy_vol - cancel_sell_vol) / total_cancel
            o['micro_order_imbalance_tox'] = float(new_imb * cancel_imb)
        else:
            o['micro_order_imbalance_tox'] = np.nan
    else:
        o['micro_order_imbalance_tox'] = np.nan
    
    # 19. micro_vpin_bayesian: 贝叶斯VPIN估计
    # 用成交方向连续性修正VPIN
    if vpin_series and len(vpin_series) >= 5:
        v = np.array(vpin_series)
        # 贝叶斯收缩: posterior = (prior*n + sample_mean) / (n + 1)
        prior = 0.5  # 无信息先验
        sample_mean = np.mean(v)
        sample_var = np.var(v)
        n_samples = len(v)
        if sample_var > 0:
            shrinkage = n_samples / (n_samples + prior * prior / sample_var)
            posterior = prior + shrinkage * (sample_mean - prior)
            o['micro_vpin_bayesian'] = float(posterior)
        else:
            o['micro_vpin_bayesian'] = float(sample_mean)
    else:
        o['micro_vpin_bayesian'] = np.nan
    
    return o

def _all_keys():
    return [
        'micro_vpin_100','micro_vpin_kyle','micro_vpin_quantile_ratio',
        'micro_vpin_tail_risk','micro_vpin_entropy',
        'micro_adverse_selection','micro_realized_spread',
        'micro_adverse_selection_cost','micro_spread_decomposition',
        'micro_price_discovery','micro_information_share',
        'micro_toxicity_persistence','micro_vpin_hurst','micro_vpin_conviction',
        'micro_toxicity_asymmetry','micro_informed_ratio','micro_liquidity_mining',
        'micro_order_imbalance_tox','micro_vpin_bayesian',
    ]

if __name__ == '__main__':
    run_script(compute, 'factor_2_11_toxicity', limit=None)
