"""
2.10 流动性 (Liquidity) - 15维
数据源: deal+snapshot
"""
import numpy as np, pandas as pd
from hf_common import *

def compute(stock_dir):
    snap = load_snapshot(stock_dir)
    deal = load_deal(stock_dir)
    if snap.empty and deal.empty: return None
    o = {'wind_code': str(stock_dir).split('/')[-1]}

    # --- Amihud基础 ---
    amihud_values = []
    if not deal.empty:
        d = deal[deal['price']>0].sort_values('seconds').copy()
        if len(d) >= 3:
            d['bucket'] = (d['seconds']//300)*300
            bars = d.groupby('bucket').apply(lambda g: pd.Series({
                'vwap': np.sum(g['price']*g['volume'])/g['volume'].sum() if g['volume'].sum()>0 else np.nan,
                'amount': g['amount'].sum()
            })).dropna()
            if len(bars) >= 2:
                rets = np.abs(np.diff(np.log(bars['vwap'].values)))
                amts = bars['amount'].values[1:]
                valid = amts > 0
                amihud_values = (rets[valid] / amts[valid]) * 1e6

    # micro_liquidity_amihud_5 / amihud_20 [2维]
    if len(amihud_values) >= 5:
        o['micro_liquidity_amihud_5'] = float(np.mean(amihud_values[-5:]))
        o['micro_liquidity_amihud_20'] = float(np.mean(amihud_values[-20:]) if len(amihud_values) >= 20 else np.mean(amihud_values))
    else:
        o['micro_liquidity_amihud_5'] = np.nan
        o['micro_liquidity_amihud_20'] = np.nan

    # micro_liquidity_ratio [1维]
    if not snap.empty and not deal.empty:
        df = snap[(snap['ask_price1']>0)&(snap['bid_price1']>0)].copy()
        if not df.empty:
            df['mid'] = (df['ask_price1']+df['bid_price1'])/2
            df['spread'] = df['ask_price1']-df['bid_price1']
            avg_spread = float(df['spread'].mean())
            avg_depth = float(np.minimum(df['bid_vol1'], df['ask_vol1']).mean())
            ret_std = float(d['price'].pct_change().std()) if len(d)>1 else np.nan
            if avg_spread and avg_spread > 0 and avg_depth > 0 and ret_std and ret_std > 0:
                o['micro_liquidity_ratio'] = float(ret_std * avg_depth / avg_spread)
            else:
                o['micro_liquidity_ratio'] = np.nan
        else:
            o['micro_liquidity_ratio'] = np.nan
    else:
        o['micro_liquidity_ratio'] = np.nan

    # micro_liquidity_turnover_decay [1维]
    # 日内换手衰减: 前半小时换手率/全天换手率
    if not deal.empty and not snap.empty:
        total_vol = float(deal['volume'].sum())
        # 前30分钟成交
        early = deal[deal['seconds'] < 34200 + 1800]  # 09:30-10:00
        early_vol = float(early['volume'].sum()) if not early.empty else 0
        # 日内换手衰减 = 前半小时占比 / (0.5/4) = 前半小时占比 / 12.5%
        if total_vol > 0:
            early_ratio = early_vol / total_vol
            o['micro_liquidity_turnover_decay'] = float(early_ratio / 0.125) if early_ratio > 0 else np.nan
        else:
            o['micro_liquidity_turnover_decay'] = np.nan
    else:
        o['micro_liquidity_turnover_decay'] = np.nan

    # micro_liquidity_volume_depth_ratio [1维]
    if not snap.empty and not deal.empty:
        avg_bid_ask = float((snap['bid_vol1'] + snap['ask_vol1']).mean())
        daily_vol = float(deal['volume'].sum())
        o['micro_liquidity_volume_depth_ratio'] = safe_div(daily_vol, avg_bid_ask) if avg_bid_ask and avg_bid_ask > 0 else np.nan
    else:
        o['micro_liquidity_volume_depth_ratio'] = np.nan

    # micro_liquidity_volatility [1维]
    if len(amihud_values) >= 2:
        o['micro_liquidity_volatility'] = float(np.std(amihud_values))
    else:
        o['micro_liquidity_volatility'] = np.nan

    # micro_liquidity_extreme [1维]
    if len(amihud_values) >= 5:
        m = np.mean(amihud_values); s = np.std(amihud_values)
        if s and s > 0:
            o['micro_liquidity_extreme'] = int(np.sum(amihud_values > m + 3*s))
        else:
            o['micro_liquidity_extreme'] = 0
    else:
        o['micro_liquidity_extreme'] = 0

    # micro_liquidity_close [1维]
    if not deal.empty:
        d_close = deal[(deal['price']>0)&(deal['seconds'].between(*SEG_CLOSE))].sort_values('seconds').copy()
        if len(d_close) >= 3:
            d_close['bucket'] = (d_close['seconds']//300)*300
            bars = d_close.groupby('bucket').apply(lambda g: pd.Series({
                'vwap': np.sum(g['price']*g['volume'])/g['volume'].sum() if g['volume'].sum()>0 else np.nan,
                'amount': g['amount'].sum()
            })).dropna()
            if len(bars) >= 2:
                r = np.abs(np.diff(np.log(bars['vwap'].values)))
                a = bars['amount'].values[1:]
                v = a > 0
                if v.any():
                    o['micro_liquidity_close'] = float(np.mean(r[v]/a[v])*1e6)
                else:
                    o['micro_liquidity_close'] = np.nan
            else:
                o['micro_liquidity_close'] = np.nan
        else:
            o['micro_liquidity_close'] = np.nan
    else:
        o['micro_liquidity_close'] = np.nan

    # micro_liquidity_roll [1维]
    if not deal.empty and len(deal) >= 10:
        d = deal[deal['price']>0].sort_values('seconds').copy()
        dprice = d['price'].diff().dropna()
        cov = -dprice.autocorr(lag=1) if len(dprice) > 2 else np.nan
        o['micro_liquidity_roll'] = float(2*np.sqrt(max(0, cov))) if cov and cov > 0 else np.nan
    else:
        o['micro_liquidity_roll'] = np.nan

    # micro_liquidity_cost [1维]
    if not snap.empty:
        df = snap[(snap['ask_price1']>0)&(snap['bid_price1']>0)].copy()
        if not df.empty:
            avg_spread = float((df['ask_price1']-df['bid_price1']).mean())
            avg_impact = np.nan
            if not deal.empty and len(deal) >= 3:
                d = deal[deal['price']>0].sort_values('seconds')
                dprice = np.abs(np.diff(d['price'].values))
                avg_impact = float(np.mean(dprice))
            if avg_impact == avg_impact:
                o['micro_liquidity_cost'] = float(avg_spread + avg_impact)
            else:
                o['micro_liquidity_cost'] = float(avg_spread)
        else:
            o['micro_liquidity_cost'] = np.nan
    else:
        o['micro_liquidity_cost'] = np.nan

    # micro_liquidity_twa [1维]
    if len(amihud_values) >= 2:
        o['micro_liquidity_twa'] = float(np.mean(amihud_values))
    else:
        o['micro_liquidity_twa'] = np.nan

    # micro_liquidity_concentration [1维]
    if not deal.empty:
        d = deal[deal['price']>0].sort_values('seconds').copy()
        d['bucket'] = (d['seconds']//300)*300
        vol_5min = d.groupby('bucket')['volume'].sum()
        total_vol = float(vol_5min.sum())
        o['micro_liquidity_concentration'] = safe_div(float(vol_5min.max()), total_vol) if total_vol and total_vol > 0 else np.nan
    else:
        o['micro_liquidity_concentration'] = np.nan

    # micro_liquidity_daily_pattern [1维]
    if len(amihud_values) >= 4:
        # 用首尾5分钟vs中间近似U型
        open_val = np.mean(amihud_values[:2])
        close_val = np.mean(amihud_values[-2:])
        mid_val = np.mean(amihud_values)
        o['micro_liquidity_daily_pattern'] = safe_div((open_val+close_val)/2, mid_val) if mid_val and mid_val > 0 else np.nan
    else:
        o['micro_liquidity_daily_pattern'] = np.nan

    # micro_liquidity_relative_spread [1维]
    if not snap.empty:
        df = snap[(snap['ask_price1']>0)&(snap['bid_price1']>0)].copy()
        if not df.empty:
            df['mid'] = (df['ask_price1']+df['bid_price1'])/2
            o['micro_liquidity_relative_spread'] = float(((df['ask_price1']-df['bid_price1'])/df['mid']*100).mean())
        else:
            o['micro_liquidity_relative_spread'] = np.nan
    else:
        o['micro_liquidity_relative_spread'] = np.nan

    # micro_liquidity_holden [1维]
    if len(amihud_values) >= 1:
        amihud_pct = float(np.percentile(amihud_values, 50))
    else:
        amihud_pct = np.nan
    if not snap.empty:
        df = snap[(snap['ask_price1']>0)&(snap['bid_price1']>0)].copy()
        spread_pct = float(((df['ask_price1']-df['bid_price1'])/((df['ask_price1']+df['bid_price1'])/2)).mean()) if not df.empty else np.nan
    else:
        spread_pct = np.nan
    depth_pct = np.nan  # 简化
    vals = [v for v in [amihud_pct, spread_pct, depth_pct] if v == v]
    o['micro_liquidity_holden'] = float(np.mean(vals)) if vals else np.nan

    return o

if __name__ == '__main__':
    run_script(compute, 'factor_2_10_liquidity', limit=None)
