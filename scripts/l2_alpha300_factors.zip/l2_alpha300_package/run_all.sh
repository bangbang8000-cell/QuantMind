#!/bin/bash
# QuantMind L2高频因子计算 - 固定流程
# 使用方法: bash run_all.sh [日期] [7z文件路径]
# 示例: bash run_all.sh 20260424 /quantmind/baidudesk/20260424.7z
#       bash run_all.sh 20260331 /quantmind/baidudesk/20260331.7z

set -e

# ==================== 参数配置 ====================
DATE=${1:-20260424}
ARCHIVE=${2:-/quantmind/baidudesk/${DATE}.7z}
SCRIPT_DIR=/quantmind/scripts/hf_factors
OUTPUT_DIR=/quantmind/db/hf_test_${DATE}
SHM_DIR=/dev/shm/hf_data
WORKERS=5
BATCH_SIZE=500

# 颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

log() { echo -e "${GREEN}[$(date '+%H:%M:%S')]${NC} $1"; }
warn() { echo -e "${YELLOW}[$(date '+%H:%M:%S')] WARN:${NC} $1"; }
err() { echo -e "${RED}[$(date '+%H:%M:%S')] ERROR:${NC} $1"; }

# ==================== 步骤1: 检查环境 ====================
log "===== 步骤1: 检查环境 ====="

if [ ! -f "$ARCHIVE" ]; then
    err "7z文件不存在: $ARCHIVE"
    exit 1
fi
log "数据文件: $ARCHIVE ($(du -h $ARCHIVE | cut -f1))"

if [ ! -d "$SCRIPT_DIR" ]; then
    err "脚本目录不存在: $SCRIPT_DIR"
    exit 1
fi
log "脚本目录: $SCRIPT_DIR"

# 检查内存
MEM_AVAIL=$(free -g | awk '/Mem:/ {print $7}')
log "可用内存: ${MEM_AVAIL}GB"
if [ "$MEM_AVAIL" -lt 40 ]; then
    warn "可用内存<40G, /dev/shm可能不够存放全量数据"
fi

# 检查/dev/shm
SHM_SIZE=$(df -BG /dev/shm | awk 'NR==2 {print $2}' | tr -d 'G')
log "/dev/shm大小: ${SHM_SIZE}GB"

mkdir -p "$OUTPUT_DIR"
log "输出目录: $OUTPUT_DIR"

# ==================== 步骤2: 生成A股代码列表 ====================
log "===== 步骤2: 生成A股代码列表 ====="

CODE_FILE=/tmp/a_share_codes_${DATE}.txt
cd "$SCRIPT_DIR"
python3 -c "
from hf_common import list_stocks
import sys
stocks = list_stocks()
with open('${CODE_FILE}','w') as f:
    for s in stocks:
        f.write(f'${DATE}/{s}/*\n')
print(f'{len(stocks)} A股')
" 2>&1 | tail -1
log "A股代码列表: $CODE_FILE"

# ==================== 步骤3: 解压到/dev/shm ====================
log "===== 步骤3: 解压数据到/dev/shm ====="

rm -rf $SHM_DIR 2>/dev/null
mkdir -p $SHM_DIR

time 7z x "$ARCHIVE" @${CODE_FILE} -o$SHM_DIR -y -mmt=64 2>/dev/null

N_STOCKS=$(ls $SHM_DIR/$DATE/ 2>/dev/null | wc -l)
SHM_SIZE_USED=$(du -sh $SHM_DIR 2>/dev/null | cut -f1)
log "解压完成: ${N_STOCKS} 只股票, 占用 ${SHM_SIZE_USED}"

if [ "$N_STOCKS" -lt 4000 ]; then
    err "解压股票数<4000, 可能有问题"
    exit 1
fi

# ==================== 步骤4: 设置hf_common.py ====================
log "===== 步骤4: 配置脚本参数 ====="

# 临时修改hf_common.py的DATE_PREFIX和ARCHIVE
HF_COMMON=$SCRIPT_DIR/hf_common.py
# 备份
cp "$HF_COMMON" "${HF_COMMON}.bak"

# 替换日期和路径
sed -i "s|DATE_PREFIX = \".*\"|DATE_PREFIX = \"${DATE}\"|" "$HF_COMMON"
sed -i "s|ARCHIVE = \".*\"|ARCHIVE = \"${ARCHIVE}\"|" "$HF_COMMON"
# 同时更新OUTPUT_DIR
sed -i "s|OUTPUT_DIR = Path(\"/quantmind/db/hf_test_[0-9]*\")|OUTPUT_DIR = Path(\"/quantmind/db/hf_test_${DATE}\")|" "$HF_COMMON"
log "已更新 hf_common.py: DATE=$DATE, ARCHIVE=$ARCHIVE, OUTPUT_DIR=$OUTPUT_DIR"

# ==================== 步骤5: 并行运行12个因子脚本 ====================
log "===== 步骤5: 并行计算215维因子 ====="

SCRIPTS=(
    "factor_2_1_spread"
    "factor_2_2_rv"
    "factor_2_3_flow"
    "factor_2_4_vpin"
    "factor_2_5_depth"
    "factor_2_6_order_flow"
    "factor_2_7_segment"
    "factor_2_8_jump"
    "factor_2_9_sequence"
    "factor_2_10_liquidity"
    "factor_2_11_toxicity"
    "factor_2_12_volume"
)

PIDS=()
for script in "${SCRIPTS[@]}"; do
    log "  启动 ${script}..."
    cd "$SCRIPT_DIR"
    python3 -u -c "
import warnings; warnings.filterwarnings('ignore')
from hf_common import run_script
from ${script} import compute
run_script(compute, '${script}', limit=None)
" > "${OUTPUT_DIR}/${script}.log" 2>&1 &
    PIDS+=($!)
done

log "12个脚本已启动, 等待完成..."
log "  PIDs: ${PIDS[@]}"

# 等待所有进程完成
FAIL=0
for i in "${!PIDS[@]}"; do
    if wait ${PIDS[$i]}; then
        log "  ${SCRIPTS[$i]} 完成 ✓"
    else
        err "  ${SCRIPTS[$i]} 失败 ✗ (exit=$?)"
        FAIL=1
    fi
done

if [ $FAIL -eq 1 ]; then
    err "部分脚本失败, 请检查日志"
fi

# ==================== 步骤6: 合并并校验 ====================
log "===== 步骤6: 合并并校验 ====="

cd "$SCRIPT_DIR"
python3 -c "
import pandas as pd, numpy as np, glob, os

files = sorted(glob.glob('${OUTPUT_DIR}/factor_2_*.parquet'))
print(f'找到 {len(files)} 个parquet文件')

all_dfs = []
total_dims = 0
for f in files:
    df = pd.read_parquet(f)
    name = os.path.basename(f).replace('.parquet','')
    n_dims = len(df.columns) - 1
    total_dims += n_dims
    nan_pct = df.drop(columns=['wind_code']).isna().sum().sum() / (len(df) * n_dims) * 100
    print(f'  {name:35s}: {len(df):5d} stocks x {n_dims:3d} dims, NaN={nan_pct:.1f}%')
    all_dfs.append(df)

# 合并
merged = all_dfs[0]
for df in all_dfs[1:]:
    merged = merged.merge(df, on='wind_code', how='outer')

# 截面winsorize 1%/99%
data_cols = [c for c in merged.columns if c != 'wind_code']
for c in data_cols:
    s = pd.to_numeric(merged[c], errors='coerce')
    if s.notna().sum() > 10 and s.nunique() > 1:
        q01, q99 = s.quantile(0.01), s.quantile(0.99)
        merged[c] = s.clip(lower=q01, upper=q99)

out = '${OUTPUT_DIR}/hf_factors_all.parquet'
merged.to_parquet(out, index=False)
print(f'\\n合并: {len(merged)} stocks x {len(merged.columns)-1} dims')
print(f'保存: {out} ({os.path.getsize(out)/1024:.0f}K)')

# 校验
bug_count = 0
for c in data_cols:
    s = pd.to_numeric(merged[c], errors='coerce')
    if s.isna().all():
        print(f'  BUG: {c} 全NaN')
        bug_count += 1
    elif s.nunique() <= 1:
        print(f'  WARN: {c} 常量(nunique={s.nunique()})')
        bug_count += 1
print(f'\\n校验: {bug_count} 个问题列')
print('校验完成!' if bug_count == 0 else '请检查上述问题列')
"

# ==================== 步骤7: 清理 ====================
log "===== 步骤7: 清理临时文件 ====="

rm -rf $SHM_DIR
# 恢复hf_common.py
mv "${HF_COMMON}.bak" "$HF_COMMON" 2>/dev/null || true
rm -f $CODE_FILE

log "清理完成"
log "===== 全部完成 ====="
log "结果文件: ${OUTPUT_DIR}/hf_factors_all.parquet"
log "日志目录: ${OUTPUT_DIR}/"
