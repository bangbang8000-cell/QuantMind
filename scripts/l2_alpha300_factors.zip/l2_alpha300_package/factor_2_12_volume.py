"""
2.12 成交量与换手率补充 (Volume & Turnover Supplement) - 15维
数据源: deal + snapshot
目的: 补充直接的成交量/换手率指标及量价关系
"""
import numpy as np, pandas as pd
from hf_common import *

def compute(stock_dir):
    deal = load_deal(stock_dir)
    snap = load_snapshot(stock_dir)
    if deal.empty: return None
    o = {'wind_code': str(stock_dir).split('/')[-1]}
    
    d = deal.sort_values('seconds').reset_index(drop=True)
    secs = d['seconds'].values
    prices = d['price'].values
    vols = d['volume'].values
    amts = d['amount'].values
    sides = d['side'].values
    n = len(d)
    
    if n < 10:
        for k in _all_keys():
            o[k] = np.nan
        return o
    
    # 总成交量/额
    total_vol = float(vols.sum())
    total_amt = float(amts.sum())
    
    # ==================== 换手率 [5维] ====================
    
    # 1. vol_turnover_total: 日内总成交量(股), 跨股票可比需join流通市值计算换手率
    o['vol_turnover_total'] = float(total_vol)
    
    # 2. vol_turnover_open: 开盘30分钟换手率
    open_mask = secs < 34200 + 1800  # 09:30-10:00
    open_vol = float(vols[open_mask].sum())
    if total_vol > 0:
        o['vol_turnover_open'] = float(open_vol / total_vol)
    else:
        o['vol_turnover_open'] = np.nan
    
    # 3. vol_turnover_close: 尾盘30分钟换手率
    close_mask = secs >= 52200  # 14:30-15:00
    close_vol = float(vols[close_mask].sum())
    if total_vol > 0:
        o['vol_turnover_close'] = float(close_vol / total_vol)
    else:
        o['vol_turnover_close'] = np.nan
    
    # 4. vol_turnover_am_pm: 上午/下午换手率比
    am_mask = (secs >= 34200) & (secs < 41400)  # 09:30-11:30
    pm_mask = (secs >= 46800) & (secs < 54000)  # 13:00-15:00
    am_vol = float(vols[am_mask].sum())
    pm_vol = float(vols[pm_mask].sum())
    if pm_vol > 0:
        o['vol_turnover_am_pm'] = float(am_vol / pm_vol)
    else:
        o['vol_turnover_am_pm'] = np.nan
    
    # 5. vol_turnover_concentration: 换手集中度(前10%时间的换手占比)
    n_buckets = 10
    bs = max(n // n_buckets, 1)
    bucket_vols = [vols[i*bs:(i+1)*bs].sum() for i in range(n // bs)]
    if bucket_vols and total_vol > 0:
        ratios = [bv / total_vol for bv in bucket_vols]
        mean_ratio = 1.0 / len(ratios)
        o['vol_turnover_concentration'] = float(max(ratios) / mean_ratio) if mean_ratio > 0 else np.nan
    else:
        o['vol_turnover_concentration'] = np.nan
    
    # ==================== 量价关系 [6维] ====================
    
    # 6. vol_price_corr: 量价相关系数
    # 按分钟聚合
    minute = (secs // 60).astype(int)
    unique_min = np.unique(minute)
    if len(unique_min) > 5:
        min_vols = np.array([vols[minute == m].sum() for m in unique_min])
        min_prices = np.array([prices[minute == m].mean() for m in unique_min])
        min_rets = np.diff(min_prices) / min_prices[:-1]
        if len(min_rets) > 3 and np.std(min_vols[:-1]) > 0:
            corr = np.corrcoef(min_vols[:-1], min_rets)[0, 1]
            o['vol_price_corr'] = float(corr) if np.isfinite(corr) else np.nan
        else:
            o['vol_price_corr'] = np.nan
    else:
        o['vol_price_corr'] = np.nan
    
    # 7. vol_price_divergence: 量价背离(价格上涨但量下降, 或反之)
    if len(unique_min) > 10:
        min_rets = np.diff(min_prices) / min_prices[:-1]
        min_vol_changes = np.diff(min_vols) / (min_vols[:-1] + 1e-10)
        # 量价方向不一致的比例
        divergence = (np.sign(min_rets) != np.sign(min_vol_changes)).sum() / len(min_rets)
        o['vol_price_divergence'] = float(divergence)
    else:
        o['vol_price_divergence'] = np.nan
    
    # 8. vol_weighted_price: 成交量加权价格偏离度
    if total_vol > 0:
        vwap = float((prices * vols).sum() / total_vol)
        close_price = float(prices[-1])
        if vwap > 0:
            o['vol_weighted_price'] = float((close_price - vwap) / vwap)
        else:
            o['vol_weighted_price'] = np.nan
    else:
        o['vol_weighted_price'] = np.nan
    
    # 9. vol_up_down_ratio: 上涨/下跌成交量比
    price_changes = np.diff(prices)
    up_vol = float(vols[1:][price_changes > 0].sum())
    down_vol = float(vols[1:][price_changes < 0].sum())
    if down_vol > 0:
        o['vol_up_down_ratio'] = float(up_vol / down_vol)
    else:
        o['vol_up_down_ratio'] = np.nan
    
    # 10. vol_large_trade_intensity: 大单成交强度(大单成交额占比/大单笔数占比)
    amt_threshold = np.percentile(amts, 90)
    large_amt = float(amts[amts >= amt_threshold].sum())
    large_count = int((amts >= amt_threshold).sum())
    if total_amt > 0 and large_count > 0 and n > 0:
        amt_ratio = large_amt / total_amt
        count_ratio = large_count / n
        o['vol_large_trade_intensity'] = float(amt_ratio / count_ratio) if count_ratio > 0 else np.nan
    else:
        o['vol_large_trade_intensity'] = np.nan
    
    # 11. vol_tick_density: 成交密度(每秒成交笔数)
    trading_seconds = secs[-1] - secs[0] if len(secs) > 1 else 0
    if trading_seconds > 0:
        o['vol_tick_density'] = float(n / trading_seconds)
    else:
        o['vol_tick_density'] = np.nan
    
    # ==================== 成交量分布 [4维] ====================
    
    # 12. vol_skew: 成交量偏度(按分钟)
    if len(unique_min) > 5:
        o['vol_skew'] = float(pd.Series(min_vols).skew())
    else:
        o['vol_skew'] = np.nan
    
    # 13. vol_kurtosis: 成交量峰度(按分钟)
    if len(unique_min) > 5:
        o['vol_kurtosis'] = float(pd.Series(min_vols).kurtosis())
    else:
        o['vol_kurtosis'] = np.nan
    
    # 14. vol_gini: 成交量基尼系数(不均匀度)
    if len(unique_min) > 5 and min_vols.sum() > 0:
        sorted_v = np.sort(min_vols)
        n_v = len(sorted_v)
        cum = np.cumsum(sorted_v)
        total = cum[-1]
        if total > 0:
            # Gini = 1 - 2*sum(cum_i)/(n*total) + 1/n
            gini = 1 - 2 * (cum.sum() / (n_v * total)) + 1/n_v
            o['vol_gini'] = float(gini)
        else:
            o['vol_gini'] = np.nan
    else:
        o['vol_gini'] = np.nan
    
    # 15. vol_persistence: 成交量自相关(持续性)
    if len(unique_min) > 10:
        v = min_vols
        if np.std(v) > 0:
            corr = np.corrcoef(v[:-1], v[1:])[0, 1]
            o['vol_persistence'] = float(corr) if np.isfinite(corr) else np.nan
        else:
            o['vol_persistence'] = np.nan
    else:
        o['vol_persistence'] = np.nan
    
    return o

def _all_keys():
    return [
        'vol_turnover_total','vol_turnover_open','vol_turnover_close',
        'vol_turnover_am_pm','vol_turnover_concentration',
        'vol_price_corr','vol_price_divergence','vol_weighted_price',
        'vol_up_down_ratio','vol_large_trade_intensity','vol_tick_density',
        'vol_skew','vol_kurtosis','vol_gini','vol_persistence',
    ]

if __name__ == '__main__':
    run_script(compute, 'factor_2_12_volume', limit=None)
