"""
2.9 成交序列 (Trade Sequence) - 15维
数据源: deal
"""
import numpy as np, pandas as pd
from hf_common import *

def compute(stock_dir):
    deal = load_deal(stock_dir)
    if deal.empty: return None
    o = {'wind_code': str(stock_dir).split('/')[-1]}
    d = deal[deal['price']>0].sort_values('seconds').reset_index(drop=True).copy()
    n = len(d)
    if n < 2: return None

    sides = d['side'].values  # 0=buy, 1=sell
    secs = d['seconds'].values
    amts = d['amount'].values
    prices = d['price'].values

    # micro_trade_interval_mean/median/cv [3维]
    intervals = np.diff(secs)
    o['micro_trade_interval_mean'] = float(np.mean(intervals)) if len(intervals) else np.nan
    o['micro_trade_interval_median'] = float(np.median(intervals)) if len(intervals) else np.nan
    mean_int = np.mean(intervals) if len(intervals) else 0
    std_int = np.std(intervals) if len(intervals) else 0
    o['micro_trade_interval_cv'] = float(std_int/mean_int) if mean_int and mean_int > 0 else np.nan

    # micro_trade_zero_interval_ratio [1维]
    o['micro_trade_zero_interval_ratio'] = safe_div(int(np.sum(intervals == 0)), len(intervals))

    # micro_trade_arrival_rate [1维]
    trading_seconds = secs[-1] - secs[0] if len(secs) > 1 else 1
    o['micro_trade_arrival_rate'] = safe_div(n, trading_seconds/60.0) if trading_seconds > 0 else np.nan

    # micro_trade_sign_autocorr [1维]
    sign = np.where(sides==0, 1, -1)
    if len(sign) > 2:
        ac = np.corrcoef(sign[:-1], sign[1:])[0,1]
        o['micro_trade_sign_autocorr'] = float(ac) if ac == ac else np.nan
    else:
        o['micro_trade_sign_autocorr'] = np.nan

    # micro_trade_sign_transition_BB/BE/EB/EE [4维]
    # B=0(buy)->B, E=1(sell)->E
    b_mask = sides[:-1] == 0
    e_mask = sides[:-1] == 1
    n_b = int(b_mask.sum())
    n_e = int(e_mask.sum())
    # BB: buy->buy
    o['micro_trade_sign_transition_BB'] = safe_div(int(((sides[:-1]==0)&(sides[1:]==0)).sum()), n_b) if n_b else np.nan
    # EB: sell->buy
    o['micro_trade_sign_transition_EB'] = safe_div(int(((sides[:-1]==1)&(sides[1:]==0)).sum()), n_e) if n_e else np.nan

    # micro_trade_continuation [1维]
    # 连续同向长度的均值
    runs = []
    cur = 1
    for i in range(1, n):
        if sides[i] == sides[i-1]:
            cur += 1
        else:
            runs.append(cur)
            cur = 1
    runs.append(cur)
    o['micro_trade_continuation'] = float(np.mean(runs)) if runs else np.nan

    # micro_trade_seq_entropy [1维]
    # 4状态: BB, BE, EB, EE
    states = []
    for i in range(1, n):
        prev = 'B' if sides[i-1]==0 else 'E'
        curr = 'B' if sides[i]==0 else 'E'
        states.append(prev+curr)
    if states:
        from collections import Counter
        counts = Counter(states)
        total = len(states)
        p = np.array(list(counts.values())) / total
        o['micro_trade_seq_entropy'] = float(-(p * np.log(p)).sum())
    else:
        o['micro_trade_seq_entropy'] = np.nan

    # micro_trade_run_length [1维]
    o['micro_trade_run_length'] = int(max(runs)) if runs else 0

    # micro_trade_buy_pressure / sell_pressure [2维]
    mid = (prices[:-1] + prices[1:]) / 2
    buy_mask = sides[:-1] == 0
    sell_mask = sides[:-1] == 1
    buy_pressure = np.sum(amts[:-1][buy_mask] * np.maximum(prices[1:][buy_mask] - mid[buy_mask], 0))
    sell_pressure = np.sum(amts[:-1][sell_mask] * np.maximum(mid[sell_mask] - prices[1:][sell_mask], 0))
    o['micro_trade_buy_pressure'] = float(buy_pressure) if buy_pressure == buy_pressure else np.nan
    o['micro_trade_sell_pressure'] = float(sell_pressure) if sell_pressure == sell_pressure else np.nan

    return o

if __name__ == '__main__':
    run_script(compute, 'factor_2_9_sequence', limit=None)
