# 300维 LightGBM 因子设计方案 (v2 — 含行业轮动+概念板块)

## 概述

- **总维度**: 300维，17个风格分类
- **Part 1** OHLCV+财务衍生: 100维 (8类)
- **Part 2** Level2高频: 215维 (12类, 含2.11毒性补充+2.12成交量换手补充)
- **v2变更**: 精简25个冗余传统因子，替换为15个行业轮动因子+10个概念板块因子

---

# Part 1: OHLCV + 财务衍生 [100维] — 8类

| # | 风格 | 维度 | 变更 |
|---|------|------|------|
| 1.1 | 动量 | 20 | -5（去掉了breakout/decay/ma_gap_60_120/roc_12） |
| 1.2 | 波动率 | 10 | -5（精简短期窗口波动率） |
| 1.3 | 成交量 | 11 | -4（精简amount系列和OBV_60） |
| 1.4 | 技术指标 | 5 | -2（去掉了hl_pos和vol_price_corr_5） |
| 1.5 | 财务 | 13 | -2（去掉了ps和dividend_yield） |
| 1.6 | 截面+行业轮动 | 23 | +15（新增15个行业轮动因子） |
| 1.7 | 筹码分布 | 8 | 不变 |
| 1.8 | 概念板块 | 10 | ★ 新增（需用户补充概念映射表） |

---

## 1.1 动量风格 (Momentum) — 20维

**数据源**: 后复权价格 adj_close=close×factor

### mom_ret_1d / 3d / 5d / 10d / 20d / 60d / 120d [7维]

```
ret_t(n)=adj_close_t/adj_close_{t-n}-1
```
> 各周期收益率，不同时间维度的价格动量

### mom_ma_gap_5 / 10 / 20 [3维]

```
ma_gap_t(n)=adj_close_t/SMA(adj_close,n)-1
```
> 收盘价偏离各周期均线的幅度，均值回归信号

### mom_ema_gap_12 / 26 [2维]

```
ema_gap_t(n)=adj_close_t/EMA(adj_close,n)-1
EMA: ewm(span=n,adjust=False).mean()
```
> 收盘价偏离指数均线的幅度

### mom_macd_dif/dea/hist [3维]

```
DIF=EMA(close,12)-EMA(close,26)
DEA=EMA(DIF,9)
HIST=2×(DIF-DEA)
```
> MACD指标

### mom_rsi_6 / 14 [2维]

```
RSI=100-100/(1+RS), RS=平均涨幅/平均跌幅(Wilder平滑)
```
> 相对强弱指标，超买超卖

### mom_kdj_k / d / j [3维]

```
RSV=(close-LL_9)/(HH_9-LL_9)×100
K=EMA(RSV,3), D=EMA(K,3), J=3K-2D
```
> KDJ随机指标

---

## 1.2 波动率风格 (Volatility) — 10维

**数据源**: 后复价OHLC, r_t=adj_close_t/adj_close_{t-1}-1

### vol_std_5 / 10 / 20 [3维]

```
vol_std_t(n)=std(r_{t-n+1}...r_t)
```
> 各周期收益率标准差

### vol_true_range / vol_atr_20 [2维]

```
TR_t=max(H_t-L_t,|H_t-C_{t-1}|,|L_t-C_{t-1}|)
ATR_20=SMA(TR,20)
```
> 真实波幅和20日平均真实波幅

### vol_parkinson_10 / 20 [2维]

```
Parkinson=√((1/n)×Σln(H_i/L_i)²/(4×ln2))
```
> Parkinson极值波动率

### vol_gk_20 [1维]

```
GK=√((1/20)×Σ[0.5×ln(H/L)²-(2ln2-1)×ln(C/O)²])
```
> Garman-Klass 20日波动率

### vol_rs_20 [1维]

```
ho=ln(H/O), lo=ln(L/O), co=ln(C/O)
RS=√((1/20)×Σ[ho×(ho-co)+lo×(lo-co)])
```
> Rogers-Satchell 20日波动率

### vol_atr_14 [1维]

```
ATR_14=SMA(TR,14)
```
> 14日平均真实波幅

---

## 1.3 成交量风格 (Volume) — 11维

**数据源**: 日频 volume, amount

### liq_volume [1维]

```
liq_volume=log(volume_t)
```
> 成交量对数

### liq_amount [1维]

```
liq_amount=log(amount_t)
```
> 成交额对数

### liq_volume_ma_5 / 20 [2维]

```
SMA(volume, n)
```
> 5日和20日量均线

### liq_volume_ratio_5 / 20 [2维]

```
volume_t/liq_volume_ma_t(n)
```
> 量比（放量/缩量倍数）

### liq_amount_ma_5 / 20 [2维]

```
SMA(amount, 5)
SMA(amount, 20)
```
> 5日和20日额均线

### liq_amount_ratio_5 [1维]

```
amount_t/liq_amount_ma_5
```
> 额比

### liq_obv_20 [1维]

```
OBV_t=Σ(sign(Δclose)×volume)
liq_obv_20=OBV_t-OBV_{t-20}
```
> 20日OBV能量潮

### liq_mfi_14 [1维]

```
TP=(H+L+C)/3, MF=TP×vol
MF_ratio=正MF/负MF
MFI=100-100/(1+MF_ratio)
```
> 资金流量指标

---

## 1.4 技术指标风格 (Technical) — 5维

**数据源**: 后复价OHLCV

### tech_bb_width / tech_bb_pos [2维]

```
mid=SMA(close,20), upper=mid+2std, lower=mid-2std
bb_width=(upper-lower)/mid
bb_pos=(close-lower)/(upper-lower)
```
> 布林带宽度和价格位置

### tech_cci_20 [1维]

```
TP=(H+L+C)/3, MA=SMA(TP,20), MD=Σ|TP-MA|/20
CCI=(TP-MA)/(0.015×MD)
```
> 商品通道指标

### tech_adx_14 [1维]

```
DX=|+DI--DI|/(+DI+-DI)×100
ADX=EMA(DX,14)
```
> 平均趋向指数

### tech_vol_price_corr_20 [1维]

```
corr(ret_i, volume_i, 20天)
```
> 20日量价相关性

---

## 1.5 财务风格 (Fundamental) — 13维

**数据源**: 换手率/市值/PE/PB等（PG或baostock）

### fun_turnover_1 / 5 / 20 [3维]

```
turnover_1=vol/free_float
turnover_5=SMA(turnover,5)
turnover_20=SMA(turnover,20)
```
> 换手率

### fun_mv / fun_total_mv [2维]

```
mv=log(close×free_float)
total_mv=log(close×total_shares)
```
> 流通/总市值

### fun_pe / fun_pb [2维]

```
pe=close/EPS, pb=close/BVPS (log/winsorize)
```
> PE和PB

### fun_bp / fun_ep [2维]

```
bp=1/pe, ep=1/pe
```
> BP和EP价值因子

### fun_mv_rank / fun_value_zscore [2维]

```
mv_rank=截面百分位
value_zscore=综合pe/pb/bp截面z-score
```
> 市值排名和估值偏离

### fun_roe / fun_peg [2维]

```
roe=净利润/净资产
peg=pe/(净利润增长率×100)
```
> ROE和PEG

---

## 1.6 截面相对价值 + 行业轮动 (Cross-sectional & Industry Rotation) — 23维

**数据源**: 个股日线+全市场截面+行业分类映射表（用户提供）

### style_beta_20 / 60 / 120 [3维]

```
beta_n=Cov(r_i,r_zz500,n)/Var(r_zz500,n)
```
> Beta系数，相对中证500的系统性风险

### style_idio_vol_20 / 60 [2维]

```
ε_i=r_i-beta×r_zz500
idio_vol_n=std(ε_i,n)
```
> 特质波动率

### style_residual_ret_20 [1维]

```
residual_ret_20=Σ ε_i
```
> 残差累积收益（Alpha）

### style_size_20 [1维]

```
size_20=z-score(fun_mv, 截面)
```
> 市值因子暴露

### style_value_20 [1维]

```
value_20=z-score(fun_bp, 截面)
```
> 价值因子暴露

### ind_ret_5 / 10 / 20 [3维]

```
ind_ret_n=mean(ret_i in industry, n天)
截面排序取百分位
```
> 行业收益排名百分位，行业强弱轮动

### ind_rotation_speed_20 [1维]

```
rotation=|rank(ind_ret_5)-rank(ind_ret_20)|/100
```
> 行业轮动速度：短期vs中期排名变化，越大=行业切换越烈

### ind_strength_20 / 60 [2维]

```
strength_n=ret_n-ind_ret_n
```
> 个股相对行业的超额收益，选股Alpha

### ind_dispersion_20 [1维]

```
dispersion_20=std(ret_i in industry, 20d)
```
> 行业内部分化度，大=精选个股，小=配置行业

### ind_breadth_up_20 [1维]

```
breadth=行业内上涨数/行业总数
```
> 行业宽度，>80%=普涨，<30%=普跌

### ind_volume_ratio_20 [1维]

```
ind_vol=Σ(ind_vol_20d)/SMA(ind_vol,20)
```
> 行业量比

### ind_crowding_20 [1维]

```
crowding=Σ(ind_amount)/Σ(market_amount)的历史分位
```
> 行业拥挤度，>90分位=拥挤有回调风险

### ind_netflow_rank_20 [1维]

```
行业资金净流入的全市场排名百分位（需L2全市场聚合）
```
> 行业资金流排名

### ind_relative_pe [1维]

```
(industry_pe/market_pe)的历史分位数
```
> 行业相对估值分位

### ind_concentration [1维]

```
top5_mv_in_industry/total_mv_of_industry
```
> 行业集中度，大=龙头主导

### ind_relative_momentum_20 [1维]

```
rel_mom=ind_ret_20-market_ret_20
```
> 行业相对全市场的动量差，强于/弱于大盘

### ind_momentum_decay [1维]

```
decay=ind_ret_5-ind_ret_20
```
> 行业动量衰减，正=短期加速，负=动量衰竭

---

## 1.7 筹码分布风格 (Chip Distribution) — 8维

**数据源**: 日线OHLCV（后复权），移动成本分布算法

### 前置算法

```
bin_size=(HH-LL)/N_bins
weight_t=α^t, α=0.95~0.99
for each day t: chip_profile+=distribute_volume(vol_t,close_t,high_t,low_t)×weight_t
总筹码=Σchip, 获利筹码=Σ(价位<现价)
```

### chip_profit_ratio_20 / 60 / 120 [3维]

```
profit_ratio_N=获利筹码_N/总筹码_N
```
> 筹码获利比例，<50%=套牢多，>50%=获利多

### chip_concentration_20 [1维]

```
concentration=(price_p95-price_p5)/close
```
> 筹码集中度，越小=成本越集中

### chip_peak_distance [1维]

```
peak_price=argmax(chip_profile)
distance=(close-peak)/peak
```
> 密集峰距离，正=盈利

### chip_floating_ratio [1维]

```
floating=chip_profit_5d/total_profit
```
> 浮筹比例，高=短期获利盘多抛压大

### chip_cost_90_width [1维]

```
cost_90_width=price_p95-price_p5 (元)
```
> 筹码分布宽度

### chip_profit_delta_5 [1维]

```
delta_5=profit_ratio_20_t-profit_ratio_20_{t-5}
```
> 获利比例变化方向，>0=多头

---

## 1.8 概念/主题板块风格 (Concept & Theme) — 10维

**数据源**: 概念板块映射表（用户提供），个股可能属于多个概念板块

### concept_hot_score [1维]

```
count(concepts where ind_ret_20>3%)
```
> 热门概念覆盖数，热点中的暴露

### concept_momentum_top3 [1维]

```
mean(top3_strongest_concept_ret_20)
```
> 前3强势概念平均涨幅

### concept_exposure_top1 [1维]

```
个股在最强概念中的排名百分位
```
> 概念龙头程度

### concept_rotation_score [1维]

```
mean(|rank(concept_ret_5)-rank(concept_ret_20)|)
```
> 概念轮动暴露

### concept_crowding_max [1维]

```
max(concept_amount/market_amount)历史分位
```
> 最热概念拥挤度

### concept_diversity [1维]

```
num(concepts_of_this_stock)
```
> 概念多样性

### concept_flow_rank [1维]

```
mean(concept_netflow_percentile)
```
> 概念平均资金流排名

### concept_leader_score [1维]

```
mean(个股在所属概念中的成交额排名)
```
> 综合龙头评分

### concept_cross_sector [1维]

```
1 if 概念涉及≥2个一级行业
```
> 跨行业概念标记

### concept_volume_ratio [1维]

```
Σ(concept_volume)/market_volume
```
> 概念量占全市场比例

---

# Part 2: Level2 高频因子 [215维] - 12类

> 实现状态: 已完成, 5185只A股, 20260424数据验证通过
> 脚本路径: /quantmind/scripts/hf_factors/
> 输出路径: /quantmind/db/hf_test_20260424/hf_factors_all.parquet

| # | 风格 | 维度 | 脚本 | 数据源 |
|---|------|------|------|--------|
| 2.1 | 价差与微观结构 | 20 | factor_2_1_spread.py | snapshot+deal |
| 2.2 | 已实现波动率 | 13 | factor_2_2_rv.py | deal |
| 2.3 | 资金流与不平衡 | 25 | factor_2_3_flow.py | deal |
| 2.4 | 信息不对称(VPIN) | 14 | factor_2_4_vpin.py | deal |
| 2.5 | 订单簿深度 | 20 | factor_2_5_depth.py | snapshot |
| 2.6 | 撤单与委托流 | 20 | factor_2_6_order_flow.py | order+deal |
| 2.7 | 分时段特征 | 26 | factor_2_7_segment.py | snapshot+deal |
| 2.8 | 跳跃与价格冲击 | 15 | factor_2_8_jump.py | deal |
| 2.9 | 成交序列 | 13 | factor_2_9_sequence.py | deal |
| 2.10 | 流动性 | 15 | factor_2_10_liquidity.py | snapshot+deal |
| 2.11 | 信息不对称与毒性补充 | 19 | factor_2_11_toxicity.py | deal+snapshot+order |
| 2.12 | 成交量与换手率补充 | 15 | factor_2_12_volume.py | deal+snapshot |

> v2变更说明:
> - 删除20个冗余因子(corr=±1.0的重复对 + 1个零区分度因子micro_effective_rate)
> - 新增2.11信息不对称与毒性补充19维
> - 新增2.12成交量与换手率补充15维
> - 全部因子已做截面1%/99% winsorize
> - order_type字段: A=新增委托, D=撤单; order_code字段: B=买, S=卖
> - 时间戳格式: 8位HHMMSScc(厘), zfill(9)解析为秒, 已验证正确

---

## 2.1 价差与微观结构 (Spread & Microstructure) - 20维

**数据源**: snapshot(10档盘口)+deal(逐笔成交)
**脚本**: factor_2_1_spread.py

> 删除5个冗余因子: micro_effective_rate(零区分度), micro_quoted_spread(=qsp_equal),
> micro_qsp_amount(=qsp_volume), micro_esp_amount(=esp_volume), micro_spread_midpoint_price(=depth_weighted)

**数据源**: snapshot(10档盘口)+deal(逐笔成交)

### 前置处理

```
bid1=BidPrice1/10000, ask1=AskPrice1/10000, mid=(bid1+ask1)/2
price=Price/10000
merge_asof(deal→snap, direction=backward)
```

### micro_qsp_equal/qsp_time/qsp_volume/qsp_amount [4维]

```
qsp=(ask1-bid1)/mid×100
等权/时间/量/额四种加权
```
> 报价价差四加权，交易成本度量

### micro_esp_equal/esp_time/esp_volume/esp_amount [4维]

```
esp=2×|price-mid|/mid×100 (过滤price in [bid1,ask1])
四加权同上
```
> 有效价差四加权

### micro_aqsp / micro_aesp [2维]

```
aqsp=ask1-bid1 (元)
aesp=2×|price-mid| (元)
```
> 绝对价差

### micro_qsp_vol_20 / micro_esp_vol_20 [2维]

```
std(qsp_equal,20) / std(esp_equal,20)
```
> 价差波动率

### micro_spread_slope_1_5 / 5_10 / 1_10 [3维]

```
slope=regress(price~cum_depth)
```
> 订单簿斜率

### micro_bid_ask_vol_ratio [1维]

```
BidVol1/AskVol1
```
> 买卖1档量比

### micro_spread_recovery [1维]

```
qsp>mean+std→恢复均值的Tick数
```
> 价差恢复时间

### micro_spread_open/mid/close [3维]

```
分时段: 开盘/盘中/尾盘价差均值
```
> 三时段价差

### micro_spread_vol_ratio [1维]

```
qsp_equal/vol_realized_rv
```
> 价差波动比

### micro_spread_U_shape [1维]

```
(收盘+开盘)/2/盘中-1
```
> 价差U型程度

### micro_effective_rate [1维]

```
count(price in [bid1,ask1])/total deals
```
> 有效成交率

### micro_spread_midpoint_price [1维]

```
micro_price=(bid1+ask1)/2
```
> 微价格

### micro_quoted_spread [1维]

```
(ask1-bid1)/mid
```
> 简单报价价差

---

## 2.2 已实现波动率 (Realized Volatility) - 13维

**数据源**: deal
**脚本**: factor_2_2_rv.py

> 删除2个冗余因子: vol_realized_noise(=rv), vol_realized_continuous(=rv)

**数据源**: deal→5分钟桶VWAP

### 前置

```
time_bucket=floor(DealTime/500000000)×500000000
vwap=Σ(P×V)/Σ(V) per bucket
log_ret=100×ln(vwap_t/vwap_{t-1})
```

### vol_realized_rv [1维]

```
RV=Σlog_ret²
```
> 已实现波动率

### vol_realized_rrv [1维]

```
RRV=Σln(high/low)²/(4×ln2)
```
> 已实现范围波动

### vol_realized_rskew [1维]

```
RSkew=n×Σlog_ret³/((n-1)(n-2)RV^(3/2))
```
> 已实现偏度

### vol_realized_rkurt [1维]

```
RKurt=n×Σlog_ret⁴/((n-1)(n-2)(n-3)RV²)
```
> 已实现峰度

### vol_realized_5min/10min/15min [3维]

```
不同桶频RV
```
> 三种频率RV

### vol_realized_am/pm/opening/closing [4维]

```
分时段RV
```
> 四时段波动分布

### vol_realized_jump [1维]

```
BPV=μ₁⁻²×Σ|log_ret_i|×|log_ret_{i-1}|
jump=max(RV-BPV,0)
```
> 跳跃成分

### vol_realized_continuous [1维]

```
continuous=min(RV,BPV)
```
> 连续波动

### vol_realized_sjv [1维]

```
SJV=(RV-BPV)/RV×√n
```
> 跳跃检验

### vol_realized_noise [1维]

```
noise=(RV-medRV)/(n-1)
```
> 微观噪声

---

## 2.3 资金流与不平衡 (Money Flow & Imbalance) - 25维

**数据源**: deal
**脚本**: factor_2_3_flow.py

> 删除5个冗余因子: flow_imbalance_count(=buy_ratio), flow_imbalance_amount(=net_ratio),
> flow_zone_open/mid/close(=imbalance_open/mid_am/close)

**数据源**: deal (Side: 0=主动买入, 1=主动卖出)

金额=price/10000×Volume
分单: ≥100万=特大单, 20~100万=大单, 5~20万=中单, <5万=小单

### flow_net_amount [1维]

```
Σ(buy)-Σ(sell)
```
> 总资金净流入

### flow_buy_amount/flow_sell_amount [2维]

```
Σ(amount where Side=0/1)
```
> 买入卖出总额

### flow_net_ratio [1维]

```
net/(buy+sell)
```
> 净流入比率

### flow_super_net/large_net/medium_net/small_net [4维]

```
net=buy-sell per amount category
```
> 四类分单净流入

### flow_super_ratio/large_ratio/medium_ratio/small_ratio [4维]

```
(buy-sell)/(buy+sell) per category
```
> 四类净流入比率

### flow_large_pct [1维]

```
(large+super)/total
```
> 大单金额占比

### flow_imbalance_volume/amount/count [3维]

```
(B-S)/(B+S)
```
> 三维度不平衡

### flow_imbalance_open/mid_am/mid_pm/close [4维]

```
分时段imbalance
```
> 四时段不平衡

### flow_imbalance_autocorr [1维]

```
5min桶自相关lag1
```
> 不平衡持续性

### flow_imbalance_revert_speed [1维]

```
imbalance>0.3→<0.1的分钟数
```
> 不平衡回归速度

### flow_buy_ratio/flow_sell_ratio [2维]

```
count(Side=0/1)/total
```
> 买卖笔数占比

### flow_consistency [1维]

```
连续同向tick占比
```
> 方向一致性

### flow_money_flow_index [1维]

```
上涨正资金-下跌正资金
```
> 资金流强度

### flow_big_trade_ratio [1维]

```
count(amount>=50万)/total
```
> 大额成交占比

### flow_zone_open/mid/close [3维]

```
时段净流入/全天净流入
```
> 时段资金流强度

---

## 2.4 信息不对称 VPIN (Information Asymmetry) - 14维

**数据源**: deal
**脚本**: factor_2_4_vpin.py

> 删除1个冗余因子: micro_asymmetry_ratio(=1-vpin_50)

**数据源**: deal

### 前置

```
bucket_size=ΣVol/N, bucket=floor(cumsum(Vol)/bucket_size)
```

### micro_vpin_8/20/50 [3维]

```
VPIN_N=Σ|buy-sell|/(buy+sell) over N buckets
```
> 三种粒度VPIN

### micro_vpin_ma_5/ma_20 [2维]

```
SMA(vpin,n)
```
> VPIN移动平均

### micro_vpin_delta_5 [1维]

```
vpin_t-vpin_ma_5
```
> VPIN偏离

### micro_vpin_zscore_20 [1维]

```
(vpin-mean_20)/std_20
```
> VPIN Z-score

### micro_pin [1维]

```
|buy-sell|/(buy+sell)
```
> 知情交易概率近似

### micro_order_flow_toxicity [1维]

```
VPIN×sign(Δprice)
```
> 订单流毒性

### micro_volume_sync [1维]

```
corr(个股5min量,市场5min量)
```
> 成交量同步性

### micro_asymmetry_ratio [1维]

```
1-realized_spread/effective_spread
```
> 信息不对称比率

### micro_vpin_surge [1维]

```
count(vpin>mean+2σ,20)
```
> VPIN飙升次数

### micro_vpin_trend [1维]

```
slope(vpin_i~i, i=1..20)
```
> VPIN趋势

### micro_vpin_vol_ratio/vpin_amount_ratio [2维]

```
vpin/RV, vpin/volume
```
> VPIN比值

---

## 2.5 订单簿深度 (Order Book Depth) - 20维

**数据源**: snapshot
**脚本**: factor_2_5_depth.py

**数据源**: snapshot

### micro_depth_bid/depth_ask [2维]

```
log(ΣVol_i) i=1..10
```
> 买卖总挂单量

### micro_depth_ratio_1/5/10 [3维]

```
ΣBid_1..n/ΣAsk_1..n
```
> 三档深度比

### micro_depth_weighted_bid/weighted_ask [2维]

```
Σ(Price_i×Vol_i)/ΣVol_i
```
> 加权均价

### micro_depth_concentration_bid/ask [2维]

```
H=Σ(Vol_i/total)² i=1..5
```
> 挂单集中度

### micro_depth_slope [1维]

```
regress(price~depth)
```
> 订单簿斜率

### micro_depth_effective [1维]

```
min(BidVol1,AskVol1)
```
> 有效深度

### micro_depth_recovery [1维]

```
大成交后恢复90%的Tick数
```
> 深度恢复

### micro_depth_open/mid/close [3维]

```
三时段depth_ratio均值
```
> 时段深度比

### micro_depth_volatility [1维]

```
cv=std/mean of depth_ratio, 5min
```
> 深度波动率

### micro_depth_extreme [1维]

```
(BidVol1-mean_20)/std_20
```
> 极限深度偏离

### micro_depth_imbalance_1/5/10 [3维]

```
(ΣBid-ΣAsk)/(ΣBid+ΣAsk)
```
> 深度不平衡度

---

## 2.6 撤单与委托流 (Order Cancellation & Flow) - 20维

**数据源**: order+deal
**脚本**: factor_2_6_order_flow.py
**关键字段**: order_type=A(新增)/D(撤单), order_code=B(买)/S(卖)

**数据源**: order

OrderType归类: 新增买={0,1,2,3}, 新增卖={10,11,12,13}, 撤买=-1, 撤卖=-11

### flow_cancel_rate [1维]

```
(撤买+撤卖)/(新增买+新增卖)
```
> 总撤单率

### flow_cancel_buy_rate/cancel_sell_rate [2维]

```
撤买/新增买, 撤卖/新增卖
```
> 买卖撤单率

### flow_cancel_imbalance [1维]

```
(撤买-撤卖)/(撤买+撤卖)
```
> 撤单方向不平衡

### flow_cancel_depth_dist [1维]

```
1-3档撤单/总撤单
```
> 档位撤单分布

### flow_cancel_lifetime [1维]

```
mean(撤单-委托时间)秒
```
> 挂单存活时间

### flow_cancel_hft_ratio [1维]

```
count(lifetime<1s)/cancelled
```
> 高频撤单占比

### flow_cancel_spoof [1维]

```
count(Vol>5×mean AND lifetime<3s)
```
> 虚假挂单次数

### flow_order_arrival_rate [1维]

```
新增委托数/交易分钟数
```
> 委托到达率

### flow_order_imbalance [1维]

```
(买-卖)/(买+卖)
```
> 委托量不平衡

### flow_order_book_rebuild [1维]

```
大成交后恢复90%深度的时间(秒)
```
> 委托簿重建

### flow_order_size_skew [1维]

```
skewness(Volume)
```
> 委托规模偏度

### flow_order_large_ratio [1维]

```
count(Vol>mean+3σ)/total
```
> 大单委托占比

### flow_cancel_price_deviation [1维]

```
|最优价-撤单价|/最小变动
```
> 撤单价偏离

### flow_cancel_post_price_change [1维]

```
撤单后N笔价格变化(+1/-1/0)
```
> 撤单后续方向

### flow_order_type_diversity [1维]

```
H=-Σp_k×ln(p_k)
```
> 委托类型熵

### flow_order_quality [1维]

```
成交委托/总委托
```
> 委托成交质量

### flow_order_duration_p50/p90 [2维]

```
各分位委托持续期(秒)
```
> 委托持续期中位数和90分位

### flow_cancel_cluster [1维]

```
cv=std(cancel/min)/mean(cancel/min)
```
> 撤单聚集度

---

## 2.7 分时段特征 (Time-segment Features) - 26维

**数据源**: snapshot+deal
**脚本**: factor_2_7_segment.py

> 删除4个冗余因子: micro_zone_netflow_open/close/am/pm(=imbalance对应列)
> T5时段定义修正: 46800-48600 (13:00-13:30)

**数据源**: snapshot+deal按时段切片

时段: T1=09:15~09:25集合, T2=09:30~10:00开盘, T3=10:00~11:00, T4=11:00~11:30, T5=13:00~13:30, T6=13:30~14:30, T7=14:30~14:57尾盘, T8=14:57~15:00收盘集合

### micro_zone_vol_ratio_T1~T8 [8维]

```
Σ(Vol_Tk)/Σ(Vol_all)
```
> 各时段量占比

### micro_zone_rv_ratio_AM/PM/open/close [4维]

```
RV_时段/RV_全天
```
> 各时段波动占比

### micro_zone_spread_ratio_open/mid/close [3维]

```
mean(qsp_时段)/mean(qsp_all)
```
> 各时段价差比

### micro_zone_netflow_open/am/pm/close [4维]

```
分时段净流入
```
> 时段资金流

### micro_open_gap [1维]

```
(open-prev_close)/prev_close
```
> 开盘跳空

### micro_call_auction_vol_ratio [1维]

```
Σ(Vol_T1)/Σ(Vol)
```
> 集合竞价量占比

### micro_call_auction_depth_change [1维]

```
Δtotal_vol_T1/10min
```
> 集合竞价挂单增速

### micro_close_auction_impact [1维]

```
(close-last_tick)/last_tick
```
> 收盘竞价偏离

### micro_close_squeeze [1维]

```
(ret_10min-ret_30min)/ret_30min
```
> 尾盘拉升

### micro_lunch_break_gap [1维]

```
(open_pm-close_am)/close_am
```
> 午间跳跃

### micro_zone_vpin_open [1维]

```
VPIN(T2)
```
> 开盘VPIN

### micro_zone_imbalance_am/pm [2维]

```
imbalance(AM)和(PM)
```
> 上下半天不平衡

### micro_zone_morning_evening_ratio [1维]

```
amount_am/amount_pm
```
> 上下午成交比

### micro_zone_distribution [1维]

```
H=-Σp_k×ln(p_k)
```
> 时段分布熵

---

## 2.8 跳跃与价格冲击 (Jump & Price Impact) - 15维

**数据源**: deal
**脚本**: factor_2_8_jump.py

> micro_kyle_lambda取绝对值确保为正(价格冲击系数)

**数据源**: deal

### micro_jump_count_1pct/05pct [2维]

```
count(|Δprice|/price>threshold)
```
> 跳跃次数

### micro_jump_size_mean/max [2维]

```
mean和max(jump_size)
```
> 跳跃幅度

### micro_jump_skew [1维]

```
(正跳-负跳)/总跳
```
> 跳跃方向偏度

### micro_jump_recovery_time [1维]

```
跳后回原价±0.1%的时间(秒)
```
> 恢复时间

### micro_jump_cluster [1维]

```
count(5min>=2跳)/总5min窗
```
> 跳跃聚集度

### micro_amihud_illiquidity [1维]

```
mean(|ret_i|/amount_i)×10⁶
```
> Amihud非流动性

### micro_kyle_lambda [1维]

```
Δprice=λ×signed_vol+ε, λ=cov/signed_var
```
> 价格冲击系数

### micro_price_impact_large [1维]

```
大单>50万后5笔价格变化
```
> 大单冲击

### micro_impact_elasticity [1维]

```
slope(Δprice~ln(volume))
```
> 冲击弹性

### micro_impact_cost [1维]

```
(price-mid)/mid for buy/sell
```
> 交易成本

### micro_impact_permanent_ratio [1维]

```
永久/(永久+暂时)
```
> 永久冲击占比

### micro_impact_decay_half_life [1维]

```
冲击衰减1/2所需笔数
```
> 冲击衰减

### micro_jump_flag [1维]

```
1 if any_jump
```
> 综合跳跃标记

---

## 2.9 成交序列 (Trade Sequence) - 13维

**数据源**: deal
**脚本**: factor_2_9_sequence.py

> 删除2个冗余因子: micro_trade_sign_transition_BE(=1-BB), micro_trade_sign_transition_EE(=1-EB)

**数据源**: deal

### micro_trade_interval_mean/median/cv [3维]

```
interval=DealTime_i-DealTime_{i-1}(ms)
```
> 成交间隔

### micro_trade_zero_interval_ratio [1维]

```
count(interval==0)/total
```
> 同毫秒占比

### micro_trade_arrival_rate [1维]

```
total_deal/trading_minutes
```
> 成交到达率

### micro_trade_sign_autocorr [1维]

```
sign=+1(B)/-1(S), corr(sign_i,sign_{i-1})
```
> 符号自相关

### micro_trade_sign_transition_BB/BE/EB/EE [4维]

```
P(B→B)=count(Side_i=0&Side_{i+1}=0)/count(Side_i=0)
```
> 符号转移概率

### micro_trade_continuation [1维]

```
mean(连续同向长度)
```
> 连续长度均值

### micro_trade_seq_entropy [1维]

```
H=-Σp×log(p) 4状态
```
> 序列熵

### micro_trade_run_length [1维]

```
max(连续同向长度)
```
> 最长连续

### micro_trade_buy_pressure/sell_pressure [2维]

```
Σ(amount×(close-mid)) per side
```
> 买卖压力

---

## 2.10 流动性风格 (Liquidity) - 15维

**数据源**: snapshot+deal
**脚本**: factor_2_10_liquidity.py

> micro_liquidity_turnover_decay: 前30分钟换手占比/12.5%

**数据源**: deal+snapshot

### micro_liquidity_amihud_5/20 [2维]

```
mean(Amihud, n天)
```
> 多周期Amihud

### micro_liquidity_ratio [1维]

```
(|ret|×depth)/spread
```
> 综合流动比率

### micro_liquidity_turnover_decay [1维]

```
turnover_1/turnover_20
```
> 换手率衰减

### micro_liquidity_volume_depth_ratio [1维]

```
daily_vol/mean(bid1+ask1)
```
> 量深比

### micro_liquidity_volatility [1维]

```
std(Amihud,20)
```
> 流动性波动

### micro_liquidity_extreme [1维]

```
count(Amihud>mean+3σ,20)
```
> 极端流动性

### micro_liquidity_close [1维]

```
mean(Amihud, 14:30~15:00)
```
> 收盘流动性

### micro_liquidity_roll [1维]

```
2√(max(0,-cov(Δprice)))
```
> Roll价差

### micro_liquidity_cost [1维]

```
spread+impact
```
> 全口径成本

### micro_liquidity_twa [1维]

```
mean(minute Amihud)
```
> 时间加权流动

### micro_liquidity_concentration [1维]

```
max_5min_vol/total_vol
```
> 流动集中度

### micro_liquidity_daily_pattern [1维]

```
(open+close)/2/mid Amihud
```
> U型深度

### micro_liquidity_relative_spread [1维]

```
(ask1-bid1)/mid×100
```
> 相对价差

### micro_liquidity_holden [1维]

```
mean(pct_spread,pct_depth,pct_amihud)
```
> Holden评分

---

## 2.11 信息不对称与毒性补充 (Adverse Selection & Toxicity) - 19维 ★新增

**数据源**: deal+snapshot+order
**脚本**: factor_2_11_toxicity.py
**目的**: 补充信息不对称、逆向选择成本、价格发现等微观结构深度因子

### VPIN补充 [5维]

```
micro_vpin_100       = VPIN(N=100等量分桶)
micro_vpin_kyle      = Kyle调整VPIN(signed order flow不平衡)
micro_vpin_quantile_ratio = 高毒性时段占比(VPIN>0.5)
micro_vpin_tail_risk = VPIN尾部风险(95分位)
micro_vpin_entropy   = VPIN熵(不确定性度量)
```
> 更细粒度VPIN及尾部风险度量

### 逆向选择成本 [4维]

```
micro_adverse_selection      = mean(|成交价-5秒后中间价|/成交价)
micro_realized_spread        = mean((成交价-5秒后中间价)×方向/成交价)
micro_adverse_selection_cost = 逆向选择成本/有效价差
micro_spread_decomposition   = 已实现价差/有效价差 (逆向选择占比)
```
> 价差分解: 逆向选择 vs 存货成分

### 价格发现 [2维]

```
micro_price_discovery  = var(成交回报)/var(中间价回报)
micro_information_share = corr(signed_vol, future_return)
```
> Hasbrouck信息份额近似

### 毒性持续性 [3维]

```
micro_toxicity_persistence = VPIN序列自相关
micro_vpin_hurst           = VPIN序列Hurst指数(R/S法)
micro_vpin_conviction     = 连续高毒性时长占比
```
> 信息不对称的时序持续性

### 不对称毒性 [3维]

```
micro_toxicity_asymmetry = 买方VPIN - 卖方VPIN
micro_informed_ratio     = 大单占比×方向集中度
micro_liquidity_mining   = 大单后价格冲击/大单占比
```
> 知情交易方向性及流动性挖掘

### 委托流毒性 [2维]

```
micro_order_imbalance_tox = 新增委托不平衡×撤单不平衡
micro_vpin_bayesian       = 贝叶斯收缩VPIN估计
```
> 委托流维度毒性及贝叶斯修正

---

## 2.12 成交量与换手率补充 (Volume & Turnover) - 15维 ★新增

**数据源**: deal+snapshot
**脚本**: factor_2_12_volume.py
**目的**: 补充直接成交量/换手率指标及量价关系, 增强对股价走势的预测力

### 换手率 [5维]

```
vol_turnover_total         = 日内总换手率(成交额/流通市值)
vol_turnover_open          = 开盘30分钟换手率(占全天比)
vol_turnover_close         = 尾盘30分钟换手率(占全天比)
vol_turnover_am_pm         = 上午/下午换手率比
vol_turnover_concentration = 换手集中度(前10%时间的换手占比/均匀占比)
```
> 分时段换手率分布, 反映交易活跃度的时段特征

### 量价关系 [6维]

```
vol_price_corr             = 分钟量价相关系数
vol_price_divergence        = 量价背离比例(方向不一致占比)
vol_weighted_price          = 收盘价偏离VWAP幅度
vol_up_down_ratio          = 上涨成交量/下跌成交量
vol_large_trade_intensity  = 大单成交强度(大单额占比/大单笔数占比)
vol_tick_density           = 成交密度(每秒成交笔数)
```
> 量价协同/背离, VWAP偏离, 大单强度

### 成交量分布 [4维]

```
vol_skew                   = 分钟成交量偏度
vol_kurtosis               = 分钟成交量峰度
vol_gini                   = 成交量基尼系数(不均匀度)
vol_persistence            = 成交量自相关(持续性)
```
> 成交量分布形态及持续性, 衡量交易活跃度的集中与稳定程度

---

# 附录: 数据流图

```
     日线数据+财务                            L2数据
   ┌──────────────┐                   ┌────────────────┐
   │OHLCV+factor+行业分类│                  │ snapshot|deal|order│
   └──────┬───────┘                   └───────┬──────────┘
          │                                      │
          ▼                                      ▼
   ┌──────────────────┐              ┌─────────────────────┐
   │ 后复权+行业聚合+概念映射│              │ 时间桶聚合/价格单位恢复 │
   └──────┬───────────┘              └─────────┬───────────┘
          │                                      │
          ▼                                      ▼
   ┌──────────────────┐              ┌─────────────────────┐
   │ 动量/波动率/成交量/    │              │ 价差/波动率/资金流/    │
   │ 技术/财务/截面/筹码/   │              │ VPIN/深度/撤单/跳跃   │
   │ 行业轮动/概念板块      │              │ 毒性/逆向选择/价格发现 │
   └──────┬───────────┘              └─────────┬───────────┘
          │                                      │
          └──────────────┬───────────────────────┘
                         │
                         ▼
                ┌────────────────┐
                │ 按日聚合为宽表    │
                │ [SecuCode, date, │
                │  factor_1..300]  │
                └────────┬───────┘
                         │
                         ▼
                ┌────────────────┐
                │ LightGBM 训练    │
                └────────────────┘
```
