"""
2.5 订单簿深度 (Order Book Depth) - 20维
数据源: snapshot (10档盘口)
"""
import numpy as np, pandas as pd
from hf_common import *

def compute(stock_dir):
    snap = load_snapshot(stock_dir)
    if snap.empty: return None
    o = {'wind_code': str(stock_dir).split('/')[-1]}
    df = snap[(snap['bid_price1']>0)&(snap['ask_price1']>0)].copy()
    if df.empty: return None

    bid_vols = [f'bid_vol{i}' for i in range(1,11)]
    ask_vols = [f'ask_vol{i}' for i in range(1,11)]
    bid_prices = [f'bid_price{i}' for i in range(1,11)]
    ask_prices = [f'ask_price{i}' for i in range(1,11)]

    df['total_bid'] = df[bid_vols].sum(axis=1)
    df['total_ask'] = df[ask_vols].sum(axis=1)

    # micro_depth_bid / depth_ask [2维]
    o['micro_depth_bid'] = float(np.log1p(df['total_bid'].mean()))
    o['micro_depth_ask'] = float(np.log1p(df['total_ask'].mean()))

    # micro_depth_ratio_1/5/10 [3维]
    for n, name in [(1,'1'),(5,'5'),(10,'10')]:
        bv = df[[f'bid_vol{i}' for i in range(1,n+1)]].sum(axis=1)
        av = df[[f'ask_vol{i}' for i in range(1,n+1)]].sum(axis=1)
        o[f'micro_depth_ratio_{name}'] = float((bv/av.replace(0,np.nan)).mean())

    # micro_depth_weighted_bid / weighted_ask [2维]
    wavg_bid = np.zeros(len(df)); wavg_ask = np.zeros(len(df))
    for i in range(1,11):
        wavg_bid += df[f'bid_price{i}'].values * df[f'bid_vol{i}'].values
        wavg_ask += df[f'ask_price{i}'].values * df[f'ask_vol{i}'].values
    o['micro_depth_weighted_bid'] = float(np.nanmean(wavg_bid / df['total_bid'].replace(0,np.nan).values))
    o['micro_depth_weighted_ask'] = float(np.nanmean(wavg_ask / df['total_ask'].replace(0,np.nan).values))

    # micro_depth_concentration_bid / ask [2维]
    def herfindahl(vols_df, n=5):
        total = vols_df.iloc[:, :n].sum(axis=1).replace(0, np.nan)
        shares = vols_df.iloc[:, :n].div(total, axis=0)
        return float((shares**2).sum(axis=1).mean())
    o['micro_depth_concentration_bid'] = herfindahl(df[bid_vols])
    o['micro_depth_concentration_ask'] = herfindahl(df[ask_vols])

    # micro_depth_slope [1维] (向量化)
    # bid价格随档位递减, 斜率为负是正常的, 但需winsorize极端值
    depths = np.arange(1, 11)
    bp_all = df[bid_prices].values.astype(float)
    bv_all = df[bid_vols].values.astype(float)
    slopes = []
    for i in range(len(df)):
        bv = bv_all[i]
        mask = bv > 0
        if mask.sum() >= 2:
            x = depths[mask]; y = bp_all[i][mask]; w = bv[mask]
            if x.std() > 0:
                slopes.append(np.cov(x, y, aweights=w)[0,1] / np.var(x))
    if slopes:
        s_arr = np.array(slopes)
        s_arr = np.clip(s_arr, np.nanpercentile(s_arr, 1), np.nanpercentile(s_arr, 99))
        o['micro_depth_slope'] = float(np.mean(s_arr))
    else:
        o['micro_depth_slope'] = np.nan

    # micro_depth_effective [1维]
    o['micro_depth_effective'] = float(np.minimum(df['bid_vol1'], df['ask_vol1']).mean())

    # micro_depth_recovery [1维] (向量化)
    mean_depth = df['total_bid'].mean()
    std_depth = df['total_bid'].std()
    if std_depth and std_depth > 0 and len(df) > 10:
        depth_arr = df['total_bid'].values
        below = depth_arr < mean_depth - 0.5*std_depth
        recoveries = []
        for i in np.where(below)[0]:
            remaining = depth_arr[i+1:]
            recovered = np.where(remaining >= mean_depth * 0.9)[0]
            if len(recovered) > 0:
                recoveries.append(recovered[0])
        o['micro_depth_recovery'] = float(np.mean(recoveries)) if recoveries else np.nan
    else:
        o['micro_depth_recovery'] = np.nan

    # micro_depth_open/mid/close [3维]
    for seg, name in [(SEG_OPEN,'open'),(SEG_MID,'mid'),(SEG_CLOSE,'close')]:
        seg_df = df[df['seconds'].between(*seg)]
        o[f'micro_depth_{name}'] = float((seg_df['total_bid']/seg_df['total_ask'].replace(0,np.nan)).mean()) if not seg_df.empty else np.nan

    # micro_depth_volatility [1维]
    depth_ratio = df['total_bid'] / df['total_ask'].replace(0, np.nan)
    m_dr = depth_ratio.mean(); s_dr = depth_ratio.std()
    o['micro_depth_volatility'] = float(s_dr/m_dr) if m_dr and m_dr > 0 else np.nan

    # micro_depth_extreme [1维]
    bv1_mean = df['bid_vol1'].mean(); bv1_std = df['bid_vol1'].std()
    if bv1_std and bv1_std > 0:
        o['micro_depth_extreme'] = float((df['bid_vol1'] - bv1_mean).iloc[-1] / bv1_std)
    else:
        o['micro_depth_extreme'] = np.nan

    # micro_depth_imbalance_1/5/10 [3维]
    for n, name in [(1,'1'),(5,'5'),(10,'10')]:
        bv = df[[f'bid_vol{i}' for i in range(1,n+1)]].sum(axis=1)
        av = df[[f'ask_vol{i}' for i in range(1,n+1)]].sum(axis=1)
        o[f'micro_depth_imbalance_{name}'] = float(((bv-av)/(bv+av).replace(0,np.nan)).mean())

    return o

if __name__ == '__main__':
    run_script(compute, 'factor_2_5_depth', limit=None)
