"""
2.2 已实现波动率 (Realized Volatility) - 15维
数据源: deal -> 5分钟桶VWAP
"""
import numpy as np, pandas as pd, math
from hf_common import *

def compute(stock_dir):
    deal = load_deal(stock_dir)
    if deal.empty: return None
    o = {'wind_code': str(stock_dir).split('/')[-1]}

    d = deal[deal['price']>0].copy()
    if d.empty: return None

    # 5分钟VWAP (向量化agg, 比groupby.apply快5x)
    d['bucket'] = (d['seconds']//300)*300
    d['pv'] = d['price'] * d['volume']
    g = d.groupby('bucket')
    bars = pd.DataFrame({
        'close': g['pv'].sum() / g['volume'].sum(),
        'high': g['price'].max(),
        'low': g['price'].min()
    }).dropna()
    if len(bars) < 2: return None

    r = 100.0 * np.log(bars['close']).diff().dropna()
    rng = 100.0 * (np.log(bars['high']) - np.log(bars['low']))
    rng = rng.replace([np.inf,-np.inf], np.nan).dropna()
    m = len(r)
    if m <= 0: return None

    # RV [1维]
    rv = float((r**2).sum())
    o['vol_realized_rv'] = rv

    # RRV [1维]
    o['vol_realized_rrv'] = float((rng**2).sum()) if not rng.empty else np.nan

    # RSkew [1维]
    o['vol_realized_rskew'] = float(np.sqrt(m)*float((r**3).sum())/(rv**1.5)) if rv > 0 else np.nan

    # RKurt [1维]
    o['vol_realized_rkurt'] = float(m*float((r**4).sum())/(rv**2)) if rv > 0 else np.nan

    # 5min/10min/15min RV [3维]
    for freq, name in [(300,'5min'),(600,'10min'),(900,'15min')]:
        d['bucket2'] = (d['seconds']//freq)*freq
        g2 = d.groupby('bucket2')
        b2 = (g2['pv'].sum() / g2['volume'].sum()).dropna()
        if len(b2) >= 2:
            r2 = 100.0*np.log(b2).diff().dropna()
            o[f'vol_realized_{name}'] = float((r2**2).sum())
        else:
            o[f'vol_realized_{name}'] = np.nan

    # AM/PM/opening/closing RV [4维]
    d_am = d[d['seconds'].between(*SEG_AM)]
    d_pm = d[d['seconds'].between(*SEG_PM)]
    d_open = d[d['seconds'].between(*SEG_OPEN)]
    d_close = d[d['seconds'].between(*SEG_CLOSE)]
    for seg_df, name in [(d_am,'am'),(d_pm,'pm'),(d_open,'opening'),(d_close,'closing')]:
        if seg_df.empty:
            o[f'vol_realized_{name}'] = np.nan; continue
        seg_df = seg_df.copy()
        seg_df['bucket'] = (seg_df['seconds']//300)*300
        seg_df['pv'] = seg_df['price'] * seg_df['volume']
        sg = seg_df.groupby('bucket')
        vwap = (sg['pv'].sum() / sg['volume'].sum()).dropna()
        if len(vwap) >= 2:
            r_seg = 100.0*np.log(vwap).diff().dropna()
            o[f'vol_realized_{name}'] = float((r_seg**2).sum())
        else:
            o[f'vol_realized_{name}'] = np.nan

    # Jump [1维]
    if m >= 2:
        abs_r = r.abs().reset_index(drop=True)
        bv = float((math.pi*m/(2*m-1)) * (abs_r.iloc[1:].values*abs_r.iloc[:-1].values).sum())
    else:
        bv = np.nan
    o['vol_realized_jump'] = float(max(rv-bv, 0)) if bv and bv > 0 else np.nan

    # SJV [1维]
    o['vol_realized_sjv'] = float((rv-bv)/rv*np.sqrt(m)) if (rv and bv and rv > 0) else np.nan

    return o

if __name__ == '__main__':
    run_script(compute, 'factor_2_2_rv', limit=None)
