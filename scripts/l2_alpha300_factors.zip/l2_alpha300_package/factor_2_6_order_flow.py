"""
2.6 撤单与委托流 (Order Cancellation & Flow) - 20维
数据源: 逐笔委托(order)
委托类型归类: order_type
  S=新增卖, B=新增买, -1=撤买, -11=撤卖 (实际BS标志)
"""
import numpy as np, pandas as pd
from hf_common import *

def compute(stock_dir):
    df = load_order(stock_dir)
    if df.empty: return None
    o = {'wind_code': str(stock_dir).split('/')[-1]}
    
    # 数据结构: order_type=A(新增)/D(撤单), order_code=B(买)/S(卖)
    ot = df['order_type'].astype(str).str.strip().str.upper()
    oc = df['order_code'].astype(str).str.strip().str.upper()
    
    # 新增订单
    new_mask = ot == 'A'
    # 撤单
    cancel_mask = ot == 'D'
    
    # 新增买/卖
    new_buy_mask = new_mask & (oc == 'B')
    new_sell_mask = new_mask & (oc == 'S')
    
    # 撤买/撤卖
    cancel_buy_mask = cancel_mask & (oc == 'B')
    cancel_sell_mask = cancel_mask & (oc == 'S')
    
    n_new = int(new_mask.sum())
    n_cancel = int(cancel_mask.sum())
    n_total = len(df)
    n_new_buy = int(new_buy_mask.sum())
    n_new_sell = int(new_sell_mask.sum())
    n_cancel_buy = int(cancel_buy_mask.sum())
    n_cancel_sell = int(cancel_sell_mask.sum())
    
    # flow_cancel_rate [1维]
    o['flow_cancel_rate'] = safe_div(n_cancel, n_new) if n_new else np.nan
    
    # flow_cancel_buy_rate / cancel_sell_rate [2维]
    o['flow_cancel_buy_rate'] = safe_div(n_cancel_buy, n_new_buy) if n_new_buy else np.nan
    o['flow_cancel_sell_rate'] = safe_div(n_cancel_sell, n_new_sell) if n_new_sell else np.nan
    
    # flow_cancel_imbalance [1维]
    o['flow_cancel_imbalance'] = safe_div(n_cancel_buy - n_cancel_sell, n_cancel_buy + n_cancel_sell) if (n_cancel_buy + n_cancel_sell) else np.nan
    
    # flow_cancel_depth_dist [1维]
    # 撤单价格距当日成交价中位的距离
    if n_cancel > 0 and n_new > 0:
        mid_price = df.loc[new_mask, 'price'].median()
        cancel_prices = df.loc[cancel_mask, 'price']
        valid = cancel_prices[cancel_prices > 0]
        if mid_price and mid_price > 0 and not valid.empty:
            o['flow_cancel_depth_dist'] = float((valid - mid_price).abs().mean() / mid_price)
        else:
            o['flow_cancel_depth_dist'] = np.nan
    else:
        o['flow_cancel_depth_dist'] = np.nan
    
    # flow_cancel_lifetime [1维]
    # 需要配对委托和撤单, 用委托编号关联
    # 简化: 用委托到达间隔的均值近似
    if n_total > 1:
        df_sorted = df.sort_values('seconds')
        intervals = df_sorted['seconds'].diff().dropna()
        o['flow_cancel_lifetime'] = float(intervals.mean()) if len(intervals) else np.nan
    else:
        o['flow_cancel_lifetime'] = np.nan
    
    # flow_cancel_hft_ratio [1维]
    if not cancel_mask.empty and n_cancel > 0:
        cancel_times = df.loc[cancel_mask, 'seconds'].sort_values()
        if len(cancel_times) > 1:
            diffs = cancel_times.diff().dropna()
            o['flow_cancel_hft_ratio'] = float((diffs < 1.0).sum() / n_cancel) if n_cancel else np.nan
        else:
            o['flow_cancel_hft_ratio'] = np.nan
    else:
        o['flow_cancel_hft_ratio'] = np.nan
    
    # flow_cancel_spoof [1维]
    # 虚假挂单: 大量且短时间内撤单
    if n_cancel > 0:
        mean_vol = df.loc[new_mask, 'volume'].mean() if new_mask.any() else 0
        spoof = cancel_mask & (df['volume'] > 5 * mean_vol if mean_vol and mean_vol > 0 else False)
        o['flow_cancel_spoof'] = int(spoof.sum())
    else:
        o['flow_cancel_spoof'] = 0
    
    # flow_order_arrival_rate [1维]
    trading_minutes = 240  # A股每天240分钟
    o['flow_order_arrival_rate'] = safe_div(n_total, trading_minutes)
    
    # flow_order_imbalance [1维]
    buy_vol = df.loc[new_buy_mask, 'volume'].sum()
    sell_vol = df.loc[new_sell_mask, 'volume'].sum()
    o['flow_order_imbalance'] = safe_div(buy_vol - sell_vol, buy_vol + sell_vol) if (buy_vol + sell_vol) else np.nan
    
    # flow_order_book_rebuild [1维]
    # 撤单后新挂单比率: 衡量簿重建速度
    if n_cancel > 0 and n_new > 0:
        # 按分钟分桶, 看撤单后同分钟内新挂单数
        df_sorted = df.sort_values('seconds')
        cancel_minutes = set((df.loc[cancel_mask, 'seconds'] // 60).astype(int))
        new_in_cancel_min = new_mask & (df['seconds'] // 60).astype(int).isin(cancel_minutes)
        o['flow_order_book_rebuild'] = safe_div(int(new_in_cancel_min.sum()), n_cancel)
    else:
        o['flow_order_book_rebuild'] = np.nan
    
    # flow_order_size_skew [1维]
    vols = df.loc[new_mask, 'volume']
    o['flow_order_size_skew'] = float(vols.skew()) if len(vols) > 2 else np.nan
    
    # flow_order_large_ratio [1维]
    if not vols.empty:
        mean_v = vols.mean()
        std_v = vols.std()
        if std_v and std_v > 0:
            o['flow_order_large_ratio'] = float((vols > mean_v + 3*std_v).sum() / len(vols))
        else:
            o['flow_order_large_ratio'] = np.nan
    else:
        o['flow_order_large_ratio'] = np.nan
    
    # flow_cancel_price_deviation [1维]
    if n_cancel > 0:
        best_price = df.loc[new_mask, 'price'].mean() if new_mask.any() else np.nan
        cancel_prices = df.loc[cancel_mask, 'price']
        if best_price and best_price > 0 and not cancel_prices.empty:
            tick_size = best_price * 0.001  # 0.1% 近似最小变动
            o['flow_cancel_price_deviation'] = float((cancel_prices - best_price).abs().mean() / tick_size) if tick_size > 0 else np.nan
        else:
            o['flow_cancel_price_deviation'] = np.nan
    else:
        o['flow_cancel_price_deviation'] = np.nan
    
    # flow_cancel_post_price_change [1维]
    # 撤单后短时间(5秒)内成交价变化
    if n_cancel > 0:
        deal = load_deal(stock_dir)
        if not deal.empty:
            cancel_secs = df.loc[cancel_mask, 'seconds'].values
            deal_secs = deal['seconds'].values
            deal_prices = deal['price'].values
            changes = []
            for cs in cancel_secs:
                # 找撤单后5秒内的成交
                mask = (deal_secs >= cs) & (deal_secs < cs + 5)
                if mask.sum() >= 2:
                    prices_after = deal_prices[mask]
                    changes.append(prices_after[-1] - prices_after[0])
            o['flow_cancel_post_price_change'] = float(np.mean(changes)) if changes else np.nan
        else:
            o['flow_cancel_post_price_change'] = np.nan
    else:
        o['flow_cancel_post_price_change'] = np.nan
    
    # flow_order_type_diversity [1维]
    type_counts = ot.value_counts()
    total = len(ot)
    if total > 0:
        p = type_counts / total
        o['flow_order_type_diversity'] = float(-(p * np.log(p)).sum()) if (p > 0).all() else float(-(p[p>0] * np.log(p[p>0])).sum())
    else:
        o['flow_order_type_diversity'] = np.nan
    
    # flow_order_quality [1维]
    o['flow_order_quality'] = safe_div(n_new - n_cancel, n_total) if n_total else np.nan
    
    # flow_order_duration_p50 / p90 [2维]
    # 委托持续期需要委托-撤单配对, 简化用委托间隔分位数
    if n_total > 1:
        df_sorted = df.sort_values('seconds')
        intervals = df_sorted['seconds'].diff().dropna()
        o['flow_order_duration_p50'] = float(intervals.quantile(0.5)) if len(intervals) else np.nan
        o['flow_order_duration_p90'] = float(intervals.quantile(0.9)) if len(intervals) else np.nan
    else:
        o['flow_order_duration_p50'] = np.nan
        o['flow_order_duration_p90'] = np.nan
    
    # flow_cancel_cluster [1维]
    if n_cancel > 0:
        cancel_secs = df.loc[cancel_mask, 'seconds']
        if len(cancel_secs) > 1:
            # 按分钟分桶看撤单聚集
            minute_buckets = (cancel_secs // 60).value_counts()
            o['flow_cancel_cluster'] = float(minute_buckets.std() / minute_buckets.mean()) if minute_buckets.mean() > 0 else np.nan
        else:
            o['flow_cancel_cluster'] = np.nan
    else:
        o['flow_cancel_cluster'] = np.nan
    
    return o

if __name__ == '__main__':
    run_script(compute, 'factor_2_6_order_flow', limit=None)
