"""
QuantMind L2高频因子计算 - 合并引擎v2
单次读取CSV, 调用旧版12个脚本的compute函数计算215维因子
I/O减少91.7%, 计算逻辑完全一致
"""
import warnings, time, sys, os, importlib
warnings.filterwarnings('ignore')

import numpy as np, pandas as pd
from pathlib import Path
from multiprocessing import Pool

sys.path.insert(0, os.path.dirname(__file__))

# 导入旧版hf_common的数据加载和运行器
from hf_common import (
    list_stocks, _read_csv, SNAP_COLS, DEAL_COLS, ORDER_COLS,
    SNAP_PRICE_COLS, _parse_time, chunk_list, wavg, safe_div
)

# ==================== 数据加载(只读一次) ====================
def load_all(stock_dir):
    """一次性加载snapshot+deal+order, 返回dict"""
    stock_dir = str(stock_dir)
    result = {}
    
    # snapshot
    p = Path(stock_dir) / "行情.csv"
    if p.exists():
        df = _read_csv(p)
        if df is not None and not df.empty:
            n = min(len(df.columns), len(SNAP_COLS))
            df = df.iloc[:, :n]
            df.columns = SNAP_COLS[:n]
            for c in SNAP_COLS:
                if c in ('trade_flag','bs_flag'):
                    df[c] = df[c].astype(str)
            for c in SNAP_PRICE_COLS:
                if c in df.columns:
                    df[c] = df[c] / 10000.0
            df['seconds'] = _parse_time(df['time'])
            result['snap'] = df
        else:
            result['snap'] = pd.DataFrame()
    else:
        result['snap'] = pd.DataFrame()
    
    # deal
    p = Path(stock_dir) / "逐笔成交.csv"
    if p.exists():
        df = _read_csv(p)
        if df is not None and not df.empty:
            n = min(len(df.columns), len(DEAL_COLS))
            df = df.iloc[:, :n]
            df.columns = DEAL_COLS[:n]
            bs = df['bs_flag'].astype(str).str.strip().str.upper()
            df['side'] = bs.map({'B': 0, 'S': 1})
            df = df.dropna(subset=['side']).copy()
            df['side'] = df['side'].astype(int)
            for c in ['price','volume','ask_seq','bid_seq','deal_id','deal_code','order_code']:
                df[c] = pd.to_numeric(df[c], errors='coerce')
            df['price'] = df['price'] / 10000.0
            df['volume'] = df['volume'].astype(float)
            df['amount'] = df['price'] * df['volume']
            df['seconds'] = _parse_time(df['time'])
            result['deal'] = df
        else:
            result['deal'] = pd.DataFrame()
    else:
        result['deal'] = pd.DataFrame()
    
    # order
    p = Path(stock_dir) / "逐笔委托.csv"
    if p.exists():
        df = _read_csv(p)
        if df is not None and not df.empty:
            n = min(len(df.columns), len(ORDER_COLS))
            df = df.iloc[:, :n]
            df.columns = ORDER_COLS[:n]
            for c in ORDER_COLS:
                if c in ('order_type', 'order_code'):
                    df[c] = df[c].astype(str).str.strip().str.upper()
            df['price'] = df['price'] / 10000.0
            df['seconds'] = _parse_time(df['time'])
            result['order'] = df
        else:
            result['order'] = pd.DataFrame()
    else:
        result['order'] = pd.DataFrame()
    
    return result

# ==================== 用monkey-patch让旧版compute用共享数据 ====================
# 旧版compute函数调用 load_snapshot/load_deal/load_order
# 使用模块级字典缓存(多进程安全, 每进程独立内存空间)

_cached_data = {}

def _patched_load_snapshot(stock_dir):
    """从缓存返回snapshot, 避免重复读CSV"""
    key = str(stock_dir)
    if key in _cached_data:
        return _cached_data[key].get('snap', pd.DataFrame())
    # 缓存未命中: 正常加载
    from hf_common import load_snapshot as _orig
    return _orig(stock_dir)

def _patched_load_deal(stock_dir):
    key = str(stock_dir)
    if key in _cached_data:
        return _cached_data[key].get('deal', pd.DataFrame())
    from hf_common import load_deal as _orig
    return _orig(stock_dir)

def _patched_load_order(stock_dir):
    key = str(stock_dir)
    if key in _cached_data:
        return _cached_data[key].get('order', pd.DataFrame())
    from hf_common import load_order as _orig
    return _orig(stock_dir)

# 导入旧版脚本并patch
import factor_2_1_spread, factor_2_2_rv, factor_2_3_flow, factor_2_4_vpin
import factor_2_5_depth, factor_2_6_order_flow, factor_2_7_segment, factor_2_8_jump
import factor_2_9_sequence, factor_2_10_liquidity, factor_2_11_toxicity, factor_2_12_volume

SCRIPTS = [
    factor_2_1_spread, factor_2_2_rv, factor_2_3_flow, factor_2_4_vpin,
    factor_2_5_depth, factor_2_6_order_flow, factor_2_7_segment, factor_2_8_jump,
    factor_2_9_sequence, factor_2_10_liquidity, factor_2_11_toxicity, factor_2_12_volume,
]

# Patch每个模块的load函数
for mod in SCRIPTS:
    mod.load_snapshot = _patched_load_snapshot
    mod.load_deal = _patched_load_deal
    mod.load_order = _patched_load_order

# ==================== 单股票计算 ====================
def compute_one(stock_dir):
    """加载一次数据, 调用12个旧版compute函数"""
    stock_dir_str = str(stock_dir)
    # 加载数据一次, 存入缓存
    _cached_data.clear()
    _cached_data[stock_dir_str] = load_all(stock_dir_str)
    
    result = {}
    for mod in SCRIPTS:
        try:
            r = mod.compute(stock_dir_str)
            if r:
                result.update(r)
        except Exception as e:
            mod_name = mod.__name__.split('.')[-1] if hasattr(mod, '__name__') else str(mod)
            print(f"  WARN: {mod_name} failed for {stock_dir_str}: {e}", flush=True)
    return result if result else None

# ==================== 批处理运行器 ====================
ARCHIVE = "/quantmind/baidudesk/20260422.7z"
DATE_PREFIX = "20260422"
OUTPUT_DIR = Path("/quantmind/db/hf_test_20260422")
BATCH_SIZE = 2000
WORKERS = 30
DATA_ROOT = Path("/dev/shm/hf_data") / DATE_PREFIX

def run_all(limit=None):
    stocks = list_stocks()
    if limit:
        stocks = stocks[:limit]
    batches = chunk_list(stocks, BATCH_SIZE)
    print(f"合并引擎v2: {len(stocks)} stocks, {len(batches)} batches, {WORKERS} workers", flush=True)
    
    use_shm = DATA_ROOT.exists()
    if use_shm:
        print(f"模式: /dev/shm 内存盘直读", flush=True)
    
    all_results = []
    t0 = time.time()
    for i, batch in enumerate(batches):
        if use_shm:
            stock_dirs = [str(DATA_ROOT / s) for s in batch]
        else:
            stock_dirs = [str(Path("/dev/shm/hf_data") / DATE_PREFIX / s) for s in batch]
        
        with Pool(WORKERS) as pool:
            results = pool.map(compute_one, stock_dirs)
        all_results.extend([r for r in results if r])
        
        elapsed = time.time() - t0
        done = min((i+1)*BATCH_SIZE, len(stocks))
        speed = done/elapsed if elapsed > 0 else 0
        eta = (len(stocks)-done)/speed if speed > 0 else 0
        print(f"  batch {i+1}/{len(batches)}: {len(all_results)} results, "
              f"{elapsed:.0f}s, ETA {eta:.0f}s", flush=True)
    
    if not all_results:
        print("WARNING: no results")
        return
    
    df = pd.DataFrame(all_results)
    # 截面winsorize 1%/99%
    data_cols = [c for c in df.columns if c != 'wind_code']
    for c in data_cols:
        s = pd.to_numeric(df[c], errors='coerce')
        if s.notna().sum() > 10 and s.nunique() > 1:
            q01, q99 = s.quantile(0.01), s.quantile(0.99)
            df[c] = s.clip(lower=q01, upper=q99)
    
    out = OUTPUT_DIR / "hf_factors_all.parquet"
    df.to_parquet(out, index=False)
    print(f"DONE: {df.shape} -> {out}", flush=True)
    
    # 校验
    bug_count = 0
    for c in data_cols:
        s = pd.to_numeric(df[c], errors='coerce')
        if s.isna().all():
            print(f"  BUG: {c} 全NaN")
            bug_count += 1
        elif s.nunique() <= 1:
            print(f"  WARN: {c} 常量(nunique={s.nunique()})")
            bug_count += 1
    print(f"校验: {bug_count} 个问题列", flush=True)
    print("校验完成!" if bug_count == 0 else "请检查上述问题列", flush=True)
    
    return df

if __name__ == '__main__':
    run_all(limit=None)
