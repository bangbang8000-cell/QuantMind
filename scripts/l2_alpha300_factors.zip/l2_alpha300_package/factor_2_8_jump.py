"""
2.8 跳跃与价格冲击 (Jump & Price Impact) - 15维
数据源: deal
"""
import numpy as np, pandas as pd
from hf_common import *

def compute(stock_dir):
    deal = load_deal(stock_dir)
    if deal.empty: return None
    o = {'wind_code': str(stock_dir).split('/')[-1]}
    d = deal[deal['price']>0].sort_values('seconds').reset_index(drop=True).copy()
    if len(d) < 3: return None

    prices = d['price'].values
    vols = d['volume'].values
    amts = d['amount'].values
    sides = d['side'].values  # 0=buy, 1=sell

    # 价格变化序列
    dprice = np.diff(prices)
    pct_change = dprice / prices[:-1]

    # micro_jump_count_1pct / 05pct [2维]
    o['micro_jump_count_1pct'] = int(np.sum(np.abs(pct_change) > 0.01))
    o['micro_jump_count_05pct'] = int(np.sum(np.abs(pct_change) > 0.005))

    # micro_jump_size_mean / max [2维]
    jumps = np.abs(pct_change)
    jump_mask = jumps > 0.005
    if jump_mask.any():
        o['micro_jump_size_mean'] = float(jumps[jump_mask].mean())
        o['micro_jump_size_max'] = float(jumps[jump_mask].max())
    else:
        o['micro_jump_size_mean'] = 0.0
        o['micro_jump_size_max'] = 0.0

    # micro_jump_skew [1维]
    if jump_mask.sum() >= 2:
        pos_jumps = pct_change[pct_change > 0.005]
        neg_jumps = -pct_change[pct_change < -0.005]
        o['micro_jump_skew'] = safe_div(len(pos_jumps) - len(neg_jumps), len(pos_jumps) + len(neg_jumps))
    else:
        o['micro_jump_skew'] = np.nan

    # micro_jump_recovery_time [1维]
    recovery_times = []
    for i in np.where(jump_mask)[0]:
        target = prices[i]
        for j in range(i+1, min(i+500, len(prices))):
            if abs(prices[j] - target) / target < 0.001:
                recovery_times.append(d['seconds'].iloc[j] - d['seconds'].iloc[i])
                break
    o['micro_jump_recovery_time'] = float(np.mean(recovery_times)) if recovery_times else np.nan

    # micro_jump_cluster [1维]
    d['bucket'] = (d['seconds']//300)*300
    jump_buckets = d.iloc[1:][jump_mask].groupby('bucket').size()
    total_buckets = d.groupby('bucket').size()
    cluster_count = (jump_buckets >= 2).sum()
    o['micro_jump_cluster'] = safe_div(int(cluster_count), int(len(total_buckets))) if len(total_buckets) else np.nan

    # micro_amihud_illiquidity [1维]
    rets = np.diff(np.log(prices))
    valid = amts[1:] > 0
    if valid.any():
        amihud = np.abs(rets[valid]) / amts[1:][valid]
        o['micro_amihud_illiquidity'] = float(np.mean(amihud) * 1e6)
    else:
        o['micro_amihud_illiquidity'] = np.nan

    # micro_kyle_lambda [1维]
    # Δprice = λ × signed_vol + ε, λ应为正(买压推高价格)
    signed_vol = np.where(sides[:-1]==0, vols[:-1], -vols[:-1])
    if len(dprice) >= 5 and np.var(signed_vol) > 0:
        lam = np.cov(dprice, signed_vol)[0,1] / np.var(signed_vol)
        # 取绝对值确保为正, 并winsorize
        o['micro_kyle_lambda'] = float(abs(lam))
    else:
        o['micro_kyle_lambda'] = np.nan

    # micro_price_impact_large [1维]
    mean_amt = np.mean(amts)
    large_idx = np.where(amts[:-1] > 500000)[0]
    impacts = []
    for i in large_idx:
        if i+6 < len(prices):
            impact = (prices[i+5] - prices[i]) / prices[i]
            impacts.append(impact)
    o['micro_price_impact_large'] = float(np.mean(impacts)) if impacts else np.nan

    # micro_impact_elasticity [1维]
    if len(dprice) >= 10:
        ln_vol = np.log(vols[:-1] + 1)
        if np.var(ln_vol) > 0:
            o['micro_impact_elasticity'] = float(np.polyfit(ln_vol, np.abs(dprice), 1)[0])
        else:
            o['micro_impact_elasticity'] = np.nan
    else:
        o['micro_impact_elasticity'] = np.nan

    # micro_impact_cost [1维]
    # (price-mid)/mid for buy/sell, 近似用前后价格变化
    buy_cost = []; sell_cost = []
    for i in range(1, len(prices)):
        mid = (prices[i-1] + prices[i]) / 2
        if mid > 0:
            if sides[i] == 0:
                buy_cost.append((prices[i] - mid) / mid)
            elif sides[i] == 1:
                sell_cost.append((mid - prices[i]) / mid)
    o['micro_impact_cost'] = float(np.mean(buy_cost + sell_cost)) if (buy_cost + sell_cost) else np.nan

    # micro_impact_permanent_ratio [1维]
    # 永久冲击 / (永久+暂时), 用5笔前后价格变化近似
    perm_impacts = []
    temp_impacts = []
    for i in np.where(amts > mean_amt * 3)[0]:
        if i+10 < len(prices) and i > 0:
            perm = prices[min(i+10, len(prices)-1)] - prices[i-1]
            temp = prices[i] - prices[i-1]
            perm_impacts.append(perm)
            temp_impacts.append(temp)
    if perm_impacts and (sum(np.abs(perm_impacts)) + sum(np.abs(temp_impacts))) > 0:
        o['micro_impact_permanent_ratio'] = float(sum(np.abs(perm_impacts)) / (sum(np.abs(perm_impacts)) + sum(np.abs(temp_impacts))))
    else:
        o['micro_impact_permanent_ratio'] = np.nan

    # micro_impact_decay_half_life [1维]
    decay_times = []
    for i in np.where(amts > mean_amt * 3)[0]:
        if i+20 < len(prices):
            peak = abs(prices[i] - prices[i-1])
            if peak > 0:
                for j in range(i+1, min(i+20, len(prices))):
                    if abs(prices[j] - prices[i-1]) <= peak * 0.5:
                        decay_times.append(j - i)
                        break
    o['micro_impact_decay_half_life'] = float(np.mean(decay_times)) if decay_times else np.nan

    # micro_jump_flag [1维]
    o['micro_jump_flag'] = 1 if o['micro_jump_count_05pct'] > 0 else 0

    return o

if __name__ == '__main__':
    run_script(compute, 'factor_2_8_jump', limit=None)
