"""
2.4 信息不对称VPIN (Information Asymmetry) - 15维
数据源: deal
VPIN: 等量分桶法, bucket_size=总成交量/N
"""
import numpy as np, pandas as pd, math
from hf_common import *

def _vpin(deal, n_buckets):
    d = deal[(deal['price']>0)&(deal['volume']>0)].copy()
    if d.empty: return np.nan
    d = d.sort_values('seconds')
    total_vol = d['volume'].sum()
    if total_vol <= 0: return np.nan
    bucket_size = total_vol / n_buckets
    d['cumvol'] = d['volume'].cumsum()
    d['bucket'] = (d['cumvol'] / bucket_size).astype(int)
    # 每桶buy/sell
    grp = d.groupby('bucket')
    buy_vol = grp.apply(lambda g: float(g.loc[g['side']==0,'volume'].sum()))
    sell_vol = grp.apply(lambda g: float(g.loc[g['side']==1,'volume'].sum()))
    imbalance = (buy_vol - sell_vol).abs()
    total = buy_vol + sell_vol
    valid = total > 0
    if valid.sum() == 0: return np.nan
    return float(imbalance[valid].sum() / total[valid].sum())

def compute(stock_dir):
    deal = load_deal(stock_dir)
    if deal.empty: return None
    o = {'wind_code': str(stock_dir).split('/')[-1]}
    d = deal[(deal['price']>0)&(deal['volume']>0)&(deal['side'].isin([0,1]))].copy()
    if d.empty: return None
    d = d.sort_values('seconds').reset_index(drop=True)

    # VPIN三种粒度 [3维]
    for n, name in [(8,'8'),(20,'20'),(50,'50')]:
        o[f'micro_vpin_{name}'] = _vpin(d, n)

    # VPIN时间序列(桶内滚动)用于后续特征
    n50 = 50
    total_vol = d['volume'].sum()
    bucket_size = total_vol / n50 if total_vol > 0 else 1
    d['cumvol'] = d['volume'].cumsum()
    d['bucket'] = (d['cumvol']/bucket_size).astype(int)
    grp = d.groupby('bucket')
    buy_vol = grp.apply(lambda g: float(g.loc[g['side']==0,'volume'].sum()))
    sell_vol = grp.apply(lambda g: float(g.loc[g['side']==1,'volume'].sum()))
    imb = (buy_vol-sell_vol).abs()
    tot = buy_vol+sell_vol
    vpin_series = imb/tot.replace(0, np.nan)
    vpin_series = vpin_series.dropna()

    # micro_vpin_ma_5 / ma_20 [2维]
    o['micro_vpin_ma_5'] = float(vpin_series.rolling(5, min_periods=1).mean().iloc[-1]) if len(vpin_series) else np.nan
    o['micro_vpin_ma_20'] = float(vpin_series.rolling(20, min_periods=1).mean().iloc[-1]) if len(vpin_series) else np.nan

    # micro_vpin_delta_5 [1维]
    if len(vpin_series) >= 6:
        o['micro_vpin_delta_5'] = float(vpin_series.iloc[-1] - vpin_series.iloc[-6])
    else:
        o['micro_vpin_delta_5'] = np.nan

    # micro_vpin_zscore_20 [1维]
    if len(vpin_series) >= 2:
        m = vpin_series.rolling(20, min_periods=2).mean()
        s = vpin_series.rolling(20, min_periods=2).std()
        z = (vpin_series - m)/s.replace(0, np.nan)
        o['micro_vpin_zscore_20'] = float(z.iloc[-1]) if not z.empty else np.nan
    else:
        o['micro_vpin_zscore_20'] = np.nan

    # micro_pin [1维]
    b = float(d.loc[d['side']==0,'volume'].sum())
    s = float(d.loc[d['side']==1,'volume'].sum())
    o['micro_pin'] = safe_div(abs(b-s), b+s)

    # micro_order_flow_toxicity [1维]
    price_change = d['price'].iloc[-1] - d['price'].iloc[0] if len(d)>1 else 0
    sign = 1 if price_change > 0 else (-1 if price_change < 0 else 0)
    o['micro_order_flow_toxicity'] = float(o['micro_vpin_50'] * sign) if o['micro_vpin_50'] == o['micro_vpin_50'] else np.nan

    # micro_volume_sync [1维]
    # 个股成交量与价格变动的同步性: corr(|return|, volume)
    if len(d) > 10:
        d_sorted = d.sort_values('seconds')
        rets = d_sorted['price'].pct_change().abs().dropna()
        vols = d_sorted['volume'].iloc[1:]
        if len(rets) == len(vols) and len(rets) > 2:
            o['micro_volume_sync'] = float(rets.corr(vols))
        else:
            o['micro_volume_sync'] = np.nan
    else:
        o['micro_volume_sync'] = np.nan

    # micro_vpin_surge [1维]
    if len(vpin_series) >= 2:
        m = vpin_series.mean(); s = vpin_series.std()
        if s and s > 0:
            o['micro_vpin_surge'] = int((vpin_series > m + 2*s).sum())
        else:
            o['micro_vpin_surge'] = 0
    else:
        o['micro_vpin_surge'] = 0

    # micro_vpin_trend [1维]
    if len(vpin_series) >= 3:
        x = np.arange(len(vpin_series))
        y = vpin_series.values
        if x.std() > 0:
            o['micro_vpin_trend'] = float(np.polyfit(x, y, 1)[0])
        else:
            o['micro_vpin_trend'] = np.nan
    else:
        o['micro_vpin_trend'] = np.nan

    # micro_vpin_vol_ratio / vpin_amount_ratio [2维]
    rv_proxy = float((100.0*np.log(d['price']).diff().dropna()**2).sum()) if len(d)>2 else np.nan
    o['micro_vpin_vol_ratio'] = safe_div(o['micro_vpin_50'], rv_proxy) if rv_proxy and rv_proxy > 0 else np.nan
    total_amount = d['amount'].sum()
    o['micro_vpin_amount_ratio'] = safe_div(o['micro_vpin_50'], np.log(total_amount)) if total_amount and total_amount > 0 else np.nan

    return o

if __name__ == '__main__':
    run_script(compute, 'factor_2_4_vpin', limit=None)
