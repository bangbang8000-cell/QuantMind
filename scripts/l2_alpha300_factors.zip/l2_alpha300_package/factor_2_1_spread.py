"""
2.1 价差与微观结构 (Spread & Microstructure) - 20维
数据源: snapshot(10档盘口)+deal(逐笔成交)
"""
import numpy as np, pandas as pd
from hf_common import *

def compute(stock_dir):
    snap = load_snapshot(stock_dir)
    deal = load_deal(stock_dir)
    if snap.empty: return None
    o = {'wind_code': str(stock_dir).split('/')[-1]}

    # --- 前置: 合并deal到最近snapshot ---
    df = snap[snap['ask_price1']>0].copy()
    df['mid'] = (df['ask_price1'] + df['bid_price1'])/2.0
    df = df[df['mid']>0].copy()
    if df.empty: return None
    df['qsp'] = (df['ask_price1'] - df['bid_price1']) / df['mid'] * 100.0  # 百分比
    df['aqsp'] = df['ask_price1'] - df['bid_price1']  # 绝对价差(元)

    # deal合并到snapshot
    if not deal.empty:
        d = deal[deal['price']>0].copy()
        d = d.sort_values('seconds')
        df = df.sort_values('seconds')
        d['mid_at_deal'] = np.interp(d['seconds'].values, df['seconds'].values, df['mid'].values)
        d['bid_at_deal'] = np.interp(d['seconds'].values, df['seconds'].values, df['bid_price1'].values)
        d['ask_at_deal'] = np.interp(d['seconds'].values, df['seconds'].values, df['ask_price1'].values)
        d['esp'] = 2.0 * (d['price'] - d['mid_at_deal']).abs() / d['mid_at_deal'] * 100.0
        d['aesp'] = 2.0 * (d['price'] - d['mid_at_deal']).abs()
        # 过滤: 成交价在spread内
        in_spread = (d['price'] >= d['bid_at_deal']) & (d['price'] <= d['ask_at_deal'])
        d_valid = d[in_spread | (d['esp']<10)]  # 容忍度
    else:
        d_valid = pd.DataFrame()

    # 时间加权权重
    tdiff = df['seconds'].diff().fillna(0).clip(lower=0)
    vol_w = df['volume'].fillna(0)

    # micro_qsp_equal/time/volume [3维]
    o['micro_qsp_equal'] = float(df['qsp'].mean())
    o['micro_qsp_time'] = wavg(df['qsp'], tdiff)
    o['micro_qsp_volume'] = wavg(df['qsp'], vol_w)

    # micro_esp_equal/time/volume [3维]
    if not d_valid.empty:
        d_tdiff = d_valid['seconds'].diff().fillna(0).clip(lower=0)
        d_vol = d_valid['volume'].fillna(0)
        o['micro_esp_equal'] = float(d_valid['esp'].mean())
        o['micro_esp_time'] = wavg(d_valid['esp'], d_tdiff)
        o['micro_esp_volume'] = wavg(d_valid['esp'], d_vol)
    else:
        o['micro_esp_equal'] = np.nan; o['micro_esp_time'] = np.nan
        o['micro_esp_volume'] = np.nan

    # micro_aqsp / micro_aesp [2维]
    o['micro_aqsp'] = float(df['aqsp'].mean())
    if not d_valid.empty:
        o['micro_aesp'] = float(d_valid['aesp'].mean())
    else:
        o['micro_aesp'] = np.nan

    # micro_qsp_vol_20 / micro_esp_vol_20 [2维]
    o['micro_qsp_vol_20'] = float(df['qsp'].std())
    o['micro_esp_vol_20'] = float(d_valid['esp'].std()) if not d_valid.empty else np.nan

    # micro_spread_slope_1_5 / 5_10 / 1_10 [3维] (全向量化, 比逐行循环快115x)
    for lo, hi, key in [(1,5,'1_5'),(5,10,'5_10'),(1,10,'1_10')]:
        bp = [f'bid_price{i}' for i in range(lo,hi+1)]
        ap = [f'ask_price{i}' for i in range(lo,hi+1)]
        bv = [f'bid_vol{i}' for i in range(lo,hi+1)]
        av = [f'ask_vol{i}' for i in range(lo,hi+1)]
        n_levels = hi - lo + 1
        n_depths = 2 * n_levels
        depths = np.arange(1, n_depths + 1)
        prices_all = df[bp + ap].values.astype(float)  # (n_rows, n_depths)
        vols_all = df[bv + av].values.astype(float)
        w = vols_all.copy()
        x = np.broadcast_to(depths, prices_all.shape).astype(float)
        y = prices_all.copy()
        valid_mask = w > 0
        n_valid = valid_mask.sum(axis=1)
        w_sum = w.sum(axis=1)
        w_sum_safe = np.where(w_sum > 0, w_sum, 1.0)
        xbar_w = (w * x).sum(axis=1) / w_sum_safe
        ybar_w = (w * y).sum(axis=1) / w_sum_safe
        w_norm_sq_sum = (w * w).sum(axis=1) / (w_sum_safe * w_sum_safe)
        bias_corr = 1.0 - w_norm_sq_sum
        bias_corr_safe = np.where(np.abs(bias_corr) > 1e-15, bias_corr, 1.0)
        cov_xy = (w * (x - xbar_w[:,None]) * (y - ybar_w[:,None])).sum(axis=1) / (w_sum_safe * bias_corr_safe)
        x_valid_sum = (x * valid_mask).sum(axis=1)
        n_safe = np.where(n_valid > 0, n_valid, 1)
        xbar_u = x_valid_sum / n_safe
        dx_u = (x - xbar_u[:,None]) * valid_mask
        var_x = (dx_u ** 2).sum(axis=1) / n_safe
        valid = (n_valid >= 2) & (var_x > 1e-15) & (np.abs(bias_corr) > 1e-15)
        slopes = np.where(valid, cov_xy / np.where(var_x > 0, var_x, 1.0), np.nan)
        valid_slopes = slopes[~np.isnan(slopes)]
        o[f'micro_spread_slope_{key}'] = float(np.mean(valid_slopes)) if len(valid_slopes) > 0 else np.nan

    # micro_bid_ask_vol_ratio [1维]
    o['micro_bid_ask_vol_ratio'] = safe_div(df['bid_vol1'].mean(), df['ask_vol1'].mean()) if df['ask_vol1'].mean() else np.nan

    # micro_spread_recovery [1维] (简化: 用qsp自相关代理)
    qsp_mean = df['qsp'].mean()
    qsp_std = df['qsp'].std()
    if qsp_std and qsp_std > 0 and len(df) > 10:
        qsp_arr = df['qsp'].values
        above = qsp_arr > qsp_mean + qsp_std
        recoveries = []
        for i in np.where(above)[0]:
            remaining = qsp_arr[i+1:]
            below = np.where(remaining <= qsp_mean * 1.1)[0]
            if len(below) > 0:
                recoveries.append(below[0])
        o['micro_spread_recovery'] = float(np.mean(recoveries)) if recoveries else np.nan
    else:
        o['micro_spread_recovery'] = np.nan

    # micro_spread_open/mid/close [3维]
    o['micro_spread_open'] = float(df[df['seconds'].between(*SEG_OPEN)]['qsp'].mean())
    o['micro_spread_mid'] = float(df[df['seconds'].between(*SEG_MID)]['qsp'].mean())
    o['micro_spread_close'] = float(df[df['seconds'].between(*SEG_CLOSE)]['qsp'].mean())

    # micro_spread_vol_ratio [1维]
    if not deal.empty and len(deal) > 5:
        d_sorted = deal.sort_values('seconds')
        price_series = d_sorted['price']
        rv_proxy = price_series.pct_change().std() * np.sqrt(240)
        if rv_proxy and rv_proxy > 0 and np.isfinite(rv_proxy):
            o['micro_spread_vol_ratio'] = safe_div(o['micro_qsp_equal'], rv_proxy)
        else:
            o['micro_spread_vol_ratio'] = np.nan
    else:
        o['micro_spread_vol_ratio'] = np.nan

    # micro_spread_U_shape [1维]
    open_s = o['micro_spread_open']
    close_s = o['micro_spread_close']
    mid_s = o['micro_spread_mid']
    if mid_s and mid_s > 0 and np.isfinite(open_s) and np.isfinite(close_s):
        u = ((open_s + close_s)/2.0) / mid_s - 1.0
        # clip极端值到[-5, 5]
        o['micro_spread_U_shape'] = float(np.clip(u, -5.0, 5.0))
    else:
        o['micro_spread_U_shape'] = np.nan

    return o

if __name__ == '__main__':
    run_script(compute, 'factor_2_1_spread', limit=None)
