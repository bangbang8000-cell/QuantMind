"""
QuantMind L2高频因子计算 - 共享工具模块
从7z压缩包中读取万得格式L2数据(GBK编码, 价格×10000)
"""
import subprocess, tempfile, shutil, re, time
import pandas as pd
import numpy as np
from pathlib import Path
from multiprocessing import Pool

# ==================== 配置 ====================
ARCHIVE = "/quantmind/baidudesk/20260424.7z"
DATE_PREFIX = "20260424"
OUTPUT_DIR = Path("/quantmind/db/hf_test_20260424")
BATCH_SIZE = 500
WORKERS = 5
# 内存盘路径(全量解压后直接读取, 跳过7z)
DATA_ROOT = Path("/dev/shm/hf_data") / DATE_PREFIX
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# ==================== 列定义 ====================
SNAP_COLS = [
    'wind_code','exchange_code','trade_date','time',
    'price','volume','amount','deal_count','iopv',
    'trade_flag','bs_flag','cum_volume','cum_amount',
    'high','low','open','pre_close',
] + [f'ask_price{i}' for i in range(1,11)] \
  + [f'ask_vol{i}' for i in range(1,11)] \
  + [f'bid_price{i}' for i in range(1,11)] \
  + [f'bid_vol{i}' for i in range(1,11)] \
  + ['wavg_ask','wavg_bid','total_ask_vol','total_bid_vol',
     'unweighted_index','total_var','up_cnt','down_cnt','flat_cnt']

DEAL_COLS = ['wind_code','exchange_code','trade_date','time',
             'deal_id','deal_code','order_code','bs_flag',
             'price','volume','ask_seq','bid_seq']

ORDER_COLS = ['wind_code','exchange_code','trade_date','time',
              'order_id','exch_order_id','order_type','order_code',
              'price','volume']

SNAP_PRICE_COLS = ['price','high','low','open','pre_close','wavg_ask','wavg_bid'] \
    + [f'ask_price{i}' for i in range(1,11)] + [f'bid_price{i}' for i in range(1,11)]

# ==================== 时段定义 (秒, 自午夜) ====================
SEG_CALL_AUCTION = (33300, 34000)   # 09:15-09:25集合竞价(含09:25结果快照)
SEG_OPEN  = (34200, 36000)         # 09:30-10:00
SEG_MID   = (36000, 52200)          # 10:00-14:30
SEG_CLOSE = (52200, 54000)         # 14:30-15:00
SEG_AM    = (34200, 41400)         # 09:30-11:30
SEG_PM    = (46800, 54000)         # 13:00-15:00

# ==================== 7z操作 ====================
def _is_a_share(code):
    """判断是否为A股股票(排除基金/债券/ETF等)"""
    num, exch = code.split('.')
    if exch == 'SH' and num.startswith(('600','601','603','605','688')):
        return True
    if exch == 'SZ' and num.startswith(('000','001','002','003','300','301')):
        return True
    return False

def list_stocks():
    """列出7z中所有A股股票代码(排除基金/债券/ETF等)"""
    result = subprocess.run(['7z','l',ARCHIVE], capture_output=True, text=True)
    stocks = set()
    for line in result.stdout.split('\n'):
        m = re.search(r'(\d{6}\.(SH|SZ|BJ))/', line)
        if m:
            code = m.group(1)
            if _is_a_share(code):
                stocks.add(code)
    return sorted(stocks)

def extract_batch(stock_codes, dest_dir):
    """从7z中批量解压指定股票"""
    patterns = [f"{DATE_PREFIX}/{s}/*" for s in stock_codes]
    cmd = ['7z','x',ARCHIVE] + patterns + [f'-o{dest_dir}','-y']
    subprocess.run(cmd, capture_output=True, text=True)

# ==================== CSV加载 ====================
def _read_csv(path):
    """用pyarrow引擎读取GBK编码CSV, 比dtype=str+to_numeric快3-4x"""
    try:
        return pd.read_csv(path, encoding='gbk', engine='pyarrow')
    except Exception:
        for enc in ['gb18030','utf-8']:
            try:
                return pd.read_csv(path, encoding=enc, engine='pyarrow')
            except:
                continue
    return pd.DataFrame()

def load_snapshot(stock_dir):
    """加载行情.csv -> DataFrame, 价格已÷10000"""
    p = Path(stock_dir)/"行情.csv"
    if not p.exists(): return pd.DataFrame()
    df = _read_csv(p)
    if df.empty: return pd.DataFrame()
    # CSV末尾有多余逗号导致空列
    n_cols = min(len(df.columns), len(SNAP_COLS))
    df = df.iloc[:, :n_cols]
    df.columns = SNAP_COLS[:n_cols]
    # pyarrow已自动推断数值类型, 只处理字符串列
    for c in SNAP_COLS:
        if c in ('trade_flag','bs_flag'):
            df[c] = df[c].astype(str)
    for c in SNAP_PRICE_COLS:
        if c in df.columns:
            df[c] = df[c] / 10000.0
    df['seconds'] = _parse_time(df['time'])
    return df

def load_deal(stock_dir):
    """加载逐笔成交.csv -> DataFrame, BS标志->side(0=买,1=卖), 价格已÷10000"""
    p = Path(stock_dir)/"逐笔成交.csv"
    if not p.exists(): return pd.DataFrame()
    df = _read_csv(p)
    if df.empty: return pd.DataFrame()
    # CSV末尾有多余逗号导致空列, 取前12列
    n_cols = min(len(df.columns), len(DEAL_COLS))
    df = df.iloc[:, :n_cols]
    df.columns = DEAL_COLS[:n_cols]
    # bs_flag是字符串列, pyarrow可能推断为object或int64(当全空格时)
    bs = df['bs_flag'].astype(str).str.strip().str.upper()
    df['side'] = bs.map({'B':0, 'S':1})
    df = df.dropna(subset=['side']).copy()
    df['side'] = df['side'].astype(int)
    # 数值列转换(确保float类型)
    for c in ['price','volume','ask_seq','bid_seq','deal_id','deal_code','order_code']:
        df[c] = pd.to_numeric(df[c], errors='coerce')
    df['price'] = df['price'] / 10000.0
    df['volume'] = df['volume'].astype(float)
    df['amount'] = df['price'] * df['volume']
    df['seconds'] = _parse_time(df['time'])
    return df

def load_order(stock_dir):
    """加载逐笔委托.csv -> DataFrame, 价格已÷10000"""
    p = Path(stock_dir)/"逐笔委托.csv"
    if not p.exists(): return pd.DataFrame()
    df = _read_csv(p)
    if df.empty: return pd.DataFrame()
    n_cols = min(len(df.columns), len(ORDER_COLS))
    df = df.iloc[:, :n_cols]
    df.columns = ORDER_COLS[:n_cols]
    # order_type和order_code保持字符串, pyarrow已推断其余为数值
    for c in ORDER_COLS:
        if c in ('order_type', 'order_code'):
            df[c] = df[c].astype(str).str.strip().str.upper()
    df['price'] = df['price'] / 10000.0
    df['seconds'] = _parse_time(df['time'])
    return df

def _parse_time(time_series):
    """HHMMSSccc(9位整数) -> 自午夜秒数, 纯数值计算比字符串切片快12x"""
    t = pd.to_numeric(time_series, errors='coerce')
    ms = t % 1000
    t = (t // 1000).astype(int)
    ss = t % 100
    t = t // 100
    mm = t % 100
    hh = t // 100
    return hh*3600 + mm*60 + ss + ms/1000.0

# ==================== 辅助函数 ====================
def wavg(v, w):
    """加权平均, 忽略NaN"""
    v = pd.to_numeric(v, errors='coerce')
    w = pd.to_numeric(w, errors='coerce').fillna(0)
    mask = v.notna() & w.gt(0)
    return float((v[mask]*w[mask]).sum()/w[mask].sum()) if mask.any() else np.nan

def chunk_list(items, size):
    return [items[i:i+size] for i in range(0, len(items), size)]

def safe_div(a, b):
    return float(a/b) if b and b != 0 else np.nan

# ==================== 通用运行器 ====================
def run_script(compute_fn, output_name, limit=None):
    """
    通用批处理运行器:
    - 若DATA_ROOT存在(全量解压到内存盘), 直接从内存读取
    - 否则逐批7z解压到磁盘(旧模式)
    """
    stocks = list_stocks()
    if limit:
        stocks = stocks[:limit]
    batches = chunk_list(stocks, BATCH_SIZE)
    print(f"[{output_name}] {len(stocks)} stocks, {len(batches)} batches, {WORKERS} workers", flush=True)

    use_shm = DATA_ROOT.exists()
    if use_shm:
        print(f"[{output_name}] 模式: /dev/shm 内存盘直读", flush=True)

    all_results = []
    t0 = time.time()
    for i, batch in enumerate(batches):
        if use_shm:
            stock_dirs = [str(DATA_ROOT / s) for s in batch]
        else:
            tmpdir = tempfile.mkdtemp(prefix=f"hf_{i}_")
            extract_batch(batch, tmpdir)
            stock_dirs = [str(Path(tmpdir)/DATE_PREFIX/s) for s in batch]
        with Pool(WORKERS) as pool:
            results = pool.map(compute_fn, stock_dirs)
        all_results.extend([r for r in results if r])
        if not use_shm:
            shutil.rmtree(tmpdir)
        elapsed = time.time() - t0
        done = min((i+1)*BATCH_SIZE, len(stocks))
        speed = done/elapsed if elapsed > 0 else 0
        eta = (len(stocks)-done)/speed if speed > 0 else 0
        print(f"  batch {i+1}/{len(batches)}: {len(all_results)} results, "
              f"{elapsed:.0f}s, ETA {eta:.0f}s", flush=True)
    if not all_results:
        print(f"[{output_name}] WARNING: no results")
        return
    df = pd.DataFrame(all_results)
    out = OUTPUT_DIR / f"{output_name}.parquet"
    df.to_parquet(out, index=False)
    print(f"[{output_name}] DONE: {df.shape} -> {out}", flush=True)
    return df
